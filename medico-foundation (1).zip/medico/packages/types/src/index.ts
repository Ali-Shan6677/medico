/**
 * Shared types for MEDICO. Plain TypeScript with hand-written validators because the package
 * registry was unreachable when this was written; swap the validators for Zod schemas once
 * dependencies can be installed (the shapes are intentionally schema-friendly).
 */

export type ClinicRole = "owner" | "doctor" | "assistant" | "readonly";
export type PrescriptionStatus = "draft" | "finalized" | "superseded";

export interface MedicationLine {
  position: number;
  name: string;
  strength?: string | null;
  dosage_form?: string | null;
  dose?: string | null;
  route?: string | null;
  frequency?: string | null;
  duration?: string | null;
  quantity?: string | null;
  instructions?: string | null;
}

export interface PatientSnapshot {
  id?: string;
  patient_no?: string | null;
  full_name: string;
  date_of_birth?: string | null; // ISO date
  sex?: "female" | "male" | "other" | null;
  phone?: string | null;
}

export interface ClinicSnapshot {
  id?: string;
  name: string;
  address?: string | null;
  phone?: string | null;
}

export interface DoctorSnapshot {
  id?: string;
  full_name: string;
  qualifications?: string | null;
  registration_no?: string | null;
  specialty?: string | null;
}

/**
 * Everything needed to render a prescription document. The database writes exactly this shape
 * (plus `status`) into `prescription_versions.content` when a prescription is finalized, so PDFs
 * for issued prescriptions are always rendered from the immutable snapshot, never from live rows.
 */
export interface PrescriptionDocument {
  rx_number: string;
  status: PrescriptionStatus;
  issued_at?: string | null; // ISO timestamp (finalized_at)
  diagnosis?: string | null;
  advice?: string | null;
  followup_advice?: string | null;
  amends_rx_number?: string | null;
  amendment_reason?: string | null;
  patient: PatientSnapshot;
  clinic: ClinicSnapshot;
  doctor: DoctorSnapshot;
  medications: MedicationLine[];
  /** Optional PNG or JPEG bytes of the doctor's signature. */
  signature_image?: Uint8Array | null;
}

export interface FieldIssue {
  field: string;
  message: string;
  severity: "error" | "warning";
}

const blank = (v: unknown): boolean => v === undefined || v === null || String(v).trim() === "";

/** Validate patient input before it is sent to the server (the database re-checks everything). */
export function validatePatientInput(input: {
  full_name?: string;
  date_of_birth?: string | null;
  sex?: string | null;
  phone?: string | null;
}, today: Date = new Date()): FieldIssue[] {
  const issues: FieldIssue[] = [];
  if (blank(input.full_name)) issues.push({ field: "full_name", message: "Full name is required", severity: "error" });
  if (!blank(input.date_of_birth)) {
    const d = new Date(`${input.date_of_birth}T00:00:00Z`);
    if (Number.isNaN(d.getTime())) issues.push({ field: "date_of_birth", message: "Date of birth is not a valid date", severity: "error" });
    else if (d.getTime() > today.getTime()) issues.push({ field: "date_of_birth", message: "Date of birth cannot be in the future", severity: "error" });
  }
  if (!blank(input.sex) && !["female", "male", "other"].includes(String(input.sex))) {
    issues.push({ field: "sex", message: "Sex must be female, male or other", severity: "error" });
  }
  if (!blank(input.phone) && !/^[+()\d\s-]{7,20}$/.test(String(input.phone))) {
    issues.push({ field: "phone", message: "Phone number looks invalid", severity: "warning" });
  }
  return issues;
}
