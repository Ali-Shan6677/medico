import { describe, test } from "node:test";
import assert from "node:assert/strict";
import { generatePrescriptionPdf } from "./index.ts";
import { readPdf } from "./testing.ts";
import type { PrescriptionDocument, MedicationLine } from "../../types/src/index.ts";

const NOW = new Date("2026-10-24T00:00:00Z");

const med = (i: number, name = `Medicine ${i}`): MedicationLine => ({
  position: i, name, strength: "500 mg", dosage_form: "Tablet", dose: "1 tablet", route: "Oral",
  frequency: "Twice daily", duration: "5 days", quantity: "10", instructions: "After meals",
});

const base = (over: Partial<PrescriptionDocument> = {}): PrescriptionDocument => ({
  rx_number: "RX-000007",
  status: "finalized",
  issued_at: "2026-10-23T09:30:00Z",
  diagnosis: "Viral fever",
  advice: "Rest and plenty of fluids",
  followup_advice: "Review in 5 days",
  patient: { patient_no: "P-000012", full_name: "Ayesha Khan", date_of_birth: "1990-04-02", sex: "female", phone: "+92 311 1111111" },
  clinic: { name: "Alice Clinic", address: "12 Mall Road, Lahore", phone: "+92 300 0000001" },
  doctor: { full_name: "Dr Alice", qualifications: "MBBS, FCPS", registration_no: "REG-1001", specialty: "General Medicine" },
  medications: [med(1, "Paracetamol"), med(2, "Amoxicillin")],
  ...over,
});

describe("prescription PDF", () => {
  test("produces a valid single-page A4 PDF that another reader can open", async () => {
    const r = await generatePrescriptionPdf(base(), { now: NOW });
    assert.equal(Buffer.from(r.bytes.slice(0, 5)).toString("latin1"), "%PDF-");
    assert.match(Buffer.from(r.bytes.slice(-16)).toString("latin1"), /%%EOF\s*$/);
    const p = await readPdf(r.bytes);
    assert.equal(p.pageCount, 1);
    assert.equal(r.pageCount, 1);
    assert.ok(Math.abs(p.pageSizes[0]!.width - 595.28) < 0.1 && Math.abs(p.pageSizes[0]!.height - 841.89) < 0.1, "A4");
    assert.equal(p.title, "Prescription RX-000007");
    assert.deepEqual(r.warnings, []);
  });

  test("contains branding, clinic, doctor, patient, reference, date, diagnosis, medicines, advice and signature area", async () => {
    const r = await generatePrescriptionPdf(base(), { now: NOW });
    const { text } = await readPdf(r.bytes);
    for (const expected of [
      "MEDICO", "Alice Clinic", "12 Mall Road, Lahore", "+92 300 0000001",
      "Dr Alice", "MBBS, FCPS", "REG-1001", "General Medicine",
      "Ayesha Khan", "P-000012", "+92 311 1111111",
      "RX-000007", "23 Oct 2026",
      "Viral fever", "Paracetamol", "Amoxicillin", "500 mg", "Twice daily", "5 days",
      "Rest and plenty of fluids", "Review in 5 days", "Doctor's signature",
    ]) assert.ok(text.includes(expected), `missing "${expected}" in PDF text`);
    assert.ok(!text.includes("DRAFT"), "an issued prescription must not carry a draft watermark");
  });

  test("a long medication list flows onto extra pages, repeating the prescription reference on each", async () => {
    const meds = Array.from({ length: 45 }, (_, i) => med(i + 1, `Medicine number ${i + 1}`));
    const r = await generatePrescriptionPdf(base({ medications: meds }), { now: NOW });
    const p = await readPdf(r.bytes);
    assert.ok(p.pageCount >= 3, `expected several pages, got ${p.pageCount}`);
    assert.equal(r.pageCount, p.pageCount);
    for (let i = 0; i < p.pageCount; i++) {
      assert.ok(p.pages[i]!.includes("RX-000007"), `page ${i + 1} lacks the reference`);
      assert.ok(p.pages[i]!.includes(`Page ${i + 1} of ${p.pageCount}`), `page ${i + 1} lacks its page number`);
    }
    for (let i = 1; i <= 45; i++) assert.ok(p.text.includes(`Medicine number ${i} `) || p.text.endsWith(`Medicine number ${i}`), `medicine ${i} missing`);
    assert.ok(p.text.includes("Doctor's signature"));
  });

  test("optional fields may be missing", async () => {
    const r = await generatePrescriptionPdf(base({
      diagnosis: null, advice: null, followup_advice: null,
      patient: { full_name: "Walk-in Patient" },
      clinic: { name: "Small Clinic" },
      doctor: { full_name: "Dr Minimal" },
      medications: [{ position: 1, name: "Cetirizine" }],
    }), { now: NOW });
    const { text, pageCount } = await readPdf(r.bytes);
    assert.equal(pageCount, 1);
    for (const s of ["Walk-in Patient", "Small Clinic", "Dr Minimal", "Cetirizine"]) assert.ok(text.includes(s), s);
    assert.ok(!text.includes("undefined") && !text.includes("null"));
  });

  test("very long free text wraps instead of running off the page", async () => {
    const long = "word ".repeat(400).trim();
    const r = await generatePrescriptionPdf(base({ advice: long, medications: [med(1, "Paracetamol " + "extended ".repeat(20))] }), { now: NOW });
    const p = await readPdf(r.bytes);
    assert.ok(p.pageCount >= 1);
    assert.equal((p.text.match(/\bword\b/g) ?? []).length, 400, "every word of the advice must be present");
  });

  test("characters the built-in font cannot draw are replaced and reported, never silently dropped", async () => {
    const r = await generatePrescriptionPdf(base({ patient: { full_name: "علی خان" , patient_no: "P-1" } }), { now: NOW });
    assert.equal(r.warnings.length, 1);
    assert.match(r.warnings[0]!, /Urdu|cannot be drawn/i);
    const { text } = await readPdf(r.bytes);
    assert.ok(text.includes("?"));
  });

  test("a draft is watermarked as not valid and a superseded prescription says so", async () => {
    const draft = await generatePrescriptionPdf(base({ status: "draft", issued_at: null }), { now: NOW });
    assert.ok((await readPdf(draft.bytes)).text.includes("DRAFT - NOT VALID"));
    const old = await generatePrescriptionPdf(base({ status: "superseded" }), { now: NOW });
    assert.ok((await readPdf(old.bytes)).text.includes("SUPERSEDED"));
  });

  test("an amendment states what it replaces and why", async () => {
    const r = await generatePrescriptionPdf(base({ rx_number: "RX-000007-A1", amends_rx_number: "RX-000007", amendment_reason: "Wrong dose of amoxicillin" }), { now: NOW });
    const { text } = await readPdf(r.bytes);
    assert.ok(text.includes("Amended prescription"));
    assert.ok(text.includes("Replaces RX-000007"));
    assert.ok(text.includes("Wrong dose of amoxicillin"));
  });

  test("an invalid signature image is reported and the signature line is still drawn", async () => {
    const r = await generatePrescriptionPdf(base({ signature_image: new Uint8Array([1, 2, 3, 4]) }), { now: NOW });
    assert.ok(r.warnings.some((w) => /signature/i.test(w)));
    assert.ok((await readPdf(r.bytes)).text.includes("Doctor's signature"));
  });

  test("the same document renders the same content twice (deterministic apart from the internal id)", async () => {
    const a = await readPdf((await generatePrescriptionPdf(base(), { now: NOW })).bytes);
    const b = await readPdf((await generatePrescriptionPdf(base(), { now: NOW })).bytes);
    assert.equal(a.text, b.text);
  });
});
