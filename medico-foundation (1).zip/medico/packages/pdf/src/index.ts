import { PDFDocument, StandardFonts, rgb, degrees, PDFFont, PDFPage } from "pdf-lib";
import type { PrescriptionDocument } from "../../types/src/index.ts";
import { formatAge } from "../../business-logic/src/prescription.ts";

export interface PdfResult {
  bytes: Uint8Array;
  pageCount: number;
  /** Non-fatal problems, e.g. characters the built-in font cannot draw. Show these to the user. */
  warnings: string[];
}

export interface PdfOptions {
  /** IANA time zone used to print the issue date. Defaults to Asia/Karachi. */
  timeZone?: string;
  /** Used only when the document has no issue date (drafts). Injectable for deterministic tests. */
  now?: Date;
}

// A4 in PostScript points.
const PAGE_W = 595.28;
const PAGE_H = 841.89;
const MARGIN = 40;
const CONTENT_W = PAGE_W - MARGIN * 2;
const FOOTER_H = 44;

const BLUE = rgb(0.043, 0.235, 0.549); // deep medical blue
const TEAL = rgb(0.0, 0.6, 0.6);
const NAVY = rgb(0.07, 0.1, 0.2);
const GRAY = rgb(0.4, 0.44, 0.5);
const LIGHT = rgb(0.94, 0.96, 0.98);
const RULE = rgb(0.8, 0.84, 0.9);

// Medication table columns (sum = CONTENT_W).
const COLS = [
  { key: "#", w: 24 },
  { key: "Medicine", w: 176 },
  { key: "Dose / Route", w: 100 },
  { key: "Frequency", w: 90 },
  { key: "Duration", w: 70 },
  { key: "Qty", w: 55 },
] as const;

class Writer {
  pages: PDFPage[] = [];
  page!: PDFPage;
  y = 0;
  warnings = new Set<string>();
  constructor(
    readonly doc: PDFDocument,
    readonly regular: PDFFont,
    readonly bold: PDFFont,
    readonly italic: PDFFont,
    readonly onNewPage: (w: Writer, first: boolean) => void,
  ) {}

  /** Replace characters the standard font cannot encode, and remember that we did. */
  clean(text: string | null | undefined, font: PDFFont = this.regular): string {
    if (!text) return "";
    const supported = new Set(font.getCharacterSet());
    let out = "";
    for (const ch of text.normalize("NFC").replace(/\r\n?/g, "\n").replace(/\t/g, "    ")) {
      const cp = ch.codePointAt(0)!;
      if (ch === "\n" || supported.has(cp)) out += ch;
      else {
        out += "?";
        this.warnings.add(
          "Some characters (for example Urdu script) cannot be drawn with the built-in PDF font and were replaced with '?'. Embed a Unicode font to support them.",
        );
      }
    }
    return out;
  }

  wrap(text: string | null | undefined, font: PDFFont, size: number, maxW: number): string[] {
    const cleaned = this.clean(text, font);
    if (!cleaned.trim()) return [];
    const lines: string[] = [];
    for (const para of cleaned.split("\n")) {
      if (para.trim() === "") { lines.push(""); continue; }
      let line = "";
      for (const word of para.split(/\s+/).filter(Boolean)) {
        let w = word;
        // Break a single over-long word (e.g. a long URL or run-on string) across lines.
        while (font.widthOfTextAtSize(w, size) > maxW) {
          let cut = w.length - 1;
          while (cut > 1 && font.widthOfTextAtSize(w.slice(0, cut), size) > maxW) cut--;
          if (line) { lines.push(line); line = ""; }
          lines.push(w.slice(0, cut));
          w = w.slice(cut);
        }
        const candidate = line ? `${line} ${w}` : w;
        if (font.widthOfTextAtSize(candidate, size) <= maxW) line = candidate;
        else { lines.push(line); line = w; }
      }
      lines.push(line);
    }
    return lines;
  }

  newPage(first = false) {
    this.page = this.doc.addPage([PAGE_W, PAGE_H]);
    this.pages.push(this.page);
    this.y = PAGE_H - MARGIN;
    this.onNewPage(this, first);
  }

  ensure(height: number) {
    if (this.y - height < MARGIN + FOOTER_H) this.newPage(false);
  }

  text(t: string, x: number, size: number, font: PDFFont, color = NAVY) {
    this.page.drawText(t, { x, y: this.y - size, size, font, color });
  }
}

const fmtDate = (iso: string | null | undefined, tz: string, fallback: Date) => {
  const d = iso ? new Date(iso) : fallback;
  const date = Number.isNaN(d.getTime()) ? fallback : d;
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: tz,
  }).format(date);
};

function drawLogo(page: PDFPage, x: number, yTop: number, size: number) {
  // Original MEDICO mark: a rounded blue square with a white medical cross and a teal pulse dot.
  page.drawRectangle({ x, y: yTop - size, width: size, height: size, color: BLUE, borderColor: BLUE, borderWidth: 0 });
  const t = size * 0.22;
  const c = size / 2;
  page.drawRectangle({ x: x + c - t / 2, y: yTop - size + size * 0.2, width: t, height: size * 0.6, color: rgb(1, 1, 1) });
  page.drawRectangle({ x: x + size * 0.2, y: yTop - c - t / 2, width: size * 0.6, height: t, color: rgb(1, 1, 1) });
  page.drawCircle({ x: x + size * 0.82, y: yTop - size * 0.18, size: size * 0.08, color: TEAL });
}

export async function generatePrescriptionPdf(rx: PrescriptionDocument, options: PdfOptions = {}): Promise<PdfResult> {
  const tz = options.timeZone ?? "Asia/Karachi";
  const now = options.now ?? new Date();

  const doc = await PDFDocument.create();
  const regular = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const italic = await doc.embedFont(StandardFonts.HelveticaOblique);

  doc.setTitle(`Prescription ${rx.rx_number}`);
  doc.setProducer("MEDICO");
  doc.setCreator("MEDICO");
  doc.setCreationDate(rx.issued_at ? new Date(rx.issued_at) : now);
  doc.setModificationDate(rx.issued_at ? new Date(rx.issued_at) : now);

  const w: Writer = new Writer(doc, regular, bold, italic, (wr, first) => {
    if (first) return; // the first page draws the full letterhead explicitly below
    // Continuation pages: compact header so every page identifies its prescription.
    drawLogo(wr.page, MARGIN, wr.y, 22);
    wr.page.drawText("MEDICO", { x: MARGIN + 30, y: wr.y - 15, size: 13, font: bold, color: BLUE });
    const right = wr.clean(`${rx.rx_number}  |  ${rx.patient.full_name}`, bold);
    const rw = bold.widthOfTextAtSize(right, 9);
    wr.page.drawText(right, { x: PAGE_W - MARGIN - rw, y: wr.y - 14, size: 9, font: bold, color: NAVY });
    wr.y -= 32;
    wr.page.drawLine({ start: { x: MARGIN, y: wr.y }, end: { x: PAGE_W - MARGIN, y: wr.y }, thickness: 0.8, color: RULE });
    wr.y -= 14;
    drawTableHeader(wr);
  });

  function drawTableHeader(wr: Writer) {
    wr.page.drawRectangle({ x: MARGIN, y: wr.y - 20, width: CONTENT_W, height: 20, color: BLUE });
    let x = MARGIN;
    for (const c of COLS) {
      wr.page.drawText(c.key, { x: x + 5, y: wr.y - 14, size: 8.5, font: bold, color: rgb(1, 1, 1) });
      x += c.w;
    }
    wr.y -= 20;
  }

  // ---------------------------------------------------------------- page 1: letterhead
  w.newPage(true);
  drawLogo(w.page, MARGIN, w.y, 38);
  w.page.drawText("MEDICO", { x: MARGIN + 48, y: w.y - 20, size: 20, font: bold, color: BLUE });
  w.page.drawText("Your Practice. Smarter. Simpler.", { x: MARGIN + 48, y: w.y - 34, size: 8, font: italic, color: GRAY });

  // Clinic details, right-aligned.
  const clinicLines = [
    ...w.wrap(rx.clinic.name, bold, 12, 270).map((t) => ({ t, f: bold, s: 12 })),
    ...w.wrap(rx.clinic.address, regular, 9, 270).map((t) => ({ t, f: regular, s: 9 })),
    ...(rx.clinic.phone ? [{ t: w.clean(`Tel: ${rx.clinic.phone}`), f: regular, s: 9 }] : []),
  ];
  let cy = w.y;
  for (const l of clinicLines) {
    const lw = l.f.widthOfTextAtSize(l.t, l.s);
    w.page.drawText(l.t, { x: PAGE_W - MARGIN - lw, y: cy - l.s, size: l.s, font: l.f, color: NAVY });
    cy -= l.s + 3;
  }
  w.y = Math.min(w.y - 44, cy) - 8;
  w.page.drawLine({ start: { x: MARGIN, y: w.y }, end: { x: PAGE_W - MARGIN, y: w.y }, thickness: 1.5, color: BLUE });
  w.y -= 14;

  // Doctor (left) and prescription reference (right).
  const docTop = w.y;
  const docLines: Array<{ t: string; f: PDFFont; s: number }> = [
    ...w.wrap(rx.doctor.full_name, bold, 11.5, 300).map((t) => ({ t, f: bold, s: 11.5 })),
    ...w.wrap(rx.doctor.qualifications, regular, 9, 300).map((t) => ({ t, f: regular, s: 9 })),
    ...w.wrap(rx.doctor.specialty, regular, 9, 300).map((t) => ({ t, f: regular, s: 9 })),
    ...(rx.doctor.registration_no ? [{ t: w.clean(`Reg. No: ${rx.doctor.registration_no}`), f: regular, s: 9 }] : []),
  ];
  let dy = docTop;
  for (const l of docLines) {
    w.page.drawText(l.t, { x: MARGIN, y: dy - l.s, size: l.s, font: l.f, color: NAVY });
    dy -= l.s + 3;
  }
  const refLines = [
    { label: "Prescription No.", value: w.clean(rx.rx_number) },
    { label: "Date", value: fmtDate(rx.issued_at, tz, now) },
  ];
  let ry = docTop;
  for (const r of refLines) {
    const label = `${r.label}: `;
    const full = bold.widthOfTextAtSize(r.value, 9.5) + regular.widthOfTextAtSize(label, 9);
    const x0 = PAGE_W - MARGIN - full;
    w.page.drawText(label, { x: x0, y: ry - 10, size: 9, font: regular, color: GRAY });
    w.page.drawText(r.value, { x: x0 + regular.widthOfTextAtSize(label, 9), y: ry - 10, size: 9.5, font: bold, color: NAVY });
    ry -= 15;
  }
  w.y = Math.min(dy, ry) - 8;

  // Amendment banner.
  if (rx.amends_rx_number) {
    const msg = w.wrap(`Amended prescription. Replaces ${rx.amends_rx_number}. Reason: ${rx.amendment_reason ?? "not recorded"}`, bold, 8.5, CONTENT_W - 16);
    const h = msg.length * 11 + 10;
    w.page.drawRectangle({ x: MARGIN, y: w.y - h, width: CONTENT_W, height: h, color: rgb(1, 0.96, 0.8), borderColor: rgb(0.85, 0.65, 0.1), borderWidth: 0.8 });
    msg.forEach((t, i) => w.page.drawText(t, { x: MARGIN + 8, y: w.y - 14 - i * 11, size: 8.5, font: bold, color: NAVY }));
    w.y -= h + 10;
  }

  // Patient box.
  const age = formatAge(rx.patient.date_of_birth ?? null, now);
  const sex = rx.patient.sex ? rx.patient.sex[0]!.toUpperCase() + rx.patient.sex.slice(1) : null;
  const patientBits = [
    rx.patient.patient_no ? `ID: ${rx.patient.patient_no}` : null,
    age ? `Age: ${age}` : null,
    sex ? `Sex: ${sex}` : null,
    rx.patient.phone ? `Phone: ${rx.patient.phone}` : null,
  ].filter(Boolean) as string[];
  const nameLines = w.wrap(rx.patient.full_name, bold, 12, CONTENT_W - 24);
  const metaLines = w.wrap(patientBits.join("   |   "), regular, 9, CONTENT_W - 24);
  const boxH = 26 + nameLines.length * 15 + metaLines.length * 12;
  w.page.drawRectangle({ x: MARGIN, y: w.y - boxH, width: CONTENT_W, height: boxH, color: LIGHT, borderColor: RULE, borderWidth: 0.8 });
  w.page.drawText("PATIENT", { x: MARGIN + 12, y: w.y - 14, size: 7.5, font: bold, color: TEAL });
  nameLines.forEach((t, i) => w.page.drawText(t, { x: MARGIN + 12, y: w.y - 30 - i * 15, size: 12, font: bold, color: NAVY }));
  metaLines.forEach((t, i) => w.page.drawText(t, { x: MARGIN + 12, y: w.y - 30 - nameLines.length * 15 + 3 - i * 12, size: 9, font: regular, color: GRAY }));
  w.y -= boxH + 14;

  // Diagnosis.
  const dxLines = w.wrap(rx.diagnosis, regular, 10, CONTENT_W - 70);
  if (dxLines.length) {
    w.ensure(dxLines.length * 13 + 8);
    w.page.drawText("Diagnosis:", { x: MARGIN, y: w.y - 10, size: 10, font: bold, color: BLUE });
    dxLines.forEach((t, i) => w.page.drawText(t, { x: MARGIN + 62, y: w.y - 10 - i * 13, size: 10, font: regular, color: NAVY }));
    w.y -= dxLines.length * 13 + 10;
  }

  // ---------------------------------------------------------------- medications
  w.ensure(60);
  w.page.drawText("Rx", { x: MARGIN, y: w.y - 22, size: 24, font: bold, color: BLUE });
  w.y -= 30;
  drawTableHeader(w);

  const meds = [...rx.medications].sort((a, b) => a.position - b.position);
  if (meds.length === 0) {
    w.page.drawText("No medications recorded.", { x: MARGIN + 5, y: w.y - 16, size: 9, font: italic, color: GRAY });
    w.y -= 24;
  }
  meds.forEach((m, idx) => {
    const cells = [
      [String(idx + 1)],
      [...w.wrap(m.name, bold, 9.5, COLS[1].w - 10),
       ...w.wrap([m.strength, m.dosage_form].filter(Boolean).join("  "), regular, 8.5, COLS[1].w - 10)],
      w.wrap([m.dose, m.route].filter(Boolean).join(" / "), regular, 9, COLS[2].w - 10),
      w.wrap(m.frequency, regular, 9, COLS[3].w - 10),
      w.wrap(m.duration, regular, 9, COLS[4].w - 10),
      w.wrap(m.quantity, regular, 9, COLS[5].w - 10),
    ];
    const instr = w.wrap(m.instructions ? `Instructions: ${m.instructions}` : "", italic, 8.5, CONTENT_W - COLS[0].w - 10);
    const lineCount = Math.max(1, ...cells.map((c) => c.length));
    const rowH = lineCount * 12 + 8 + (instr.length ? instr.length * 11 + 4 : 0);
    w.ensure(rowH + 2);
    let x = MARGIN;
    cells.forEach((lines, ci) => {
      lines.forEach((t, li) => {
        const font = ci === 1 && li < w.wrap(m.name, bold, 9.5, COLS[1].w - 10).length ? bold : regular;
        const size = ci === 1 && font === regular ? 8.5 : 9;
        w.page.drawText(t, { x: x + 5, y: w.y - 13 - li * 12, size: font === bold ? 9.5 : size, font, color: NAVY });
      });
      x += COLS[ci]!.w;
    });
    instr.forEach((t, i) => w.page.drawText(t, { x: MARGIN + COLS[0].w + 5, y: w.y - 13 - lineCount * 12 - i * 11 + 4, size: 8.5, font: italic, color: GRAY }));
    w.y -= rowH;
    w.page.drawLine({ start: { x: MARGIN, y: w.y }, end: { x: PAGE_W - MARGIN, y: w.y }, thickness: 0.5, color: RULE });
  });
  w.y -= 14;

  // ---------------------------------------------------------------- advice & follow-up
  for (const [label, text] of [["Advice", rx.advice], ["Follow-up", rx.followup_advice]] as const) {
    const lines = w.wrap(text, regular, 9.5, CONTENT_W);
    if (!lines.length) continue;
    w.ensure(Math.min(lines.length, 3) * 12 + 20);
    w.text(label, MARGIN, 10, bold, BLUE);
    w.y -= 15;
    for (const t of lines) {
      w.ensure(13);
      w.text(t, MARGIN, 9.5, regular);
      w.y -= 12.5;
    }
    w.y -= 8;
  }

  // ---------------------------------------------------------------- signature
  w.ensure(100);
  w.y -= 18;
  const sigX = PAGE_W - MARGIN - 190;
  if (rx.signature_image && rx.signature_image.length > 0) {
    try {
      const isPng = rx.signature_image[0] === 0x89 && rx.signature_image[1] === 0x50;
      const img = isPng ? await doc.embedPng(rx.signature_image) : await doc.embedJpg(rx.signature_image);
      const scale = Math.min(150 / img.width, 48 / img.height, 1);
      w.page.drawImage(img, { x: sigX, y: w.y - 50, width: img.width * scale, height: img.height * scale });
    } catch {
      w.warnings.add("The signature image could not be read and was left blank. Use a PNG or JPEG file.");
    }
  }
  w.y -= 54;
  w.page.drawLine({ start: { x: sigX, y: w.y }, end: { x: PAGE_W - MARGIN, y: w.y }, thickness: 0.8, color: NAVY });
  w.page.drawText(w.clean(rx.doctor.full_name, bold), { x: sigX, y: w.y - 12, size: 9.5, font: bold, color: NAVY });
  w.page.drawText("Doctor's signature", { x: sigX, y: w.y - 23, size: 8, font: regular, color: GRAY });
  w.y -= 30;

  // ---------------------------------------------------------------- watermarks and footers
  const total = w.pages.length;
  w.pages.forEach((p, i) => {
    if (rx.status !== "finalized") {
      const label = rx.status === "draft" ? "DRAFT - NOT VALID" : "SUPERSEDED";
      p.drawText(label, { x: 95, y: 250, size: 62, font: bold, color: rgb(0.85, 0.2, 0.2), opacity: 0.14, rotate: degrees(40) });
    }
    p.drawLine({ start: { x: MARGIN, y: MARGIN + 26 }, end: { x: PAGE_W - MARGIN, y: MARGIN + 26 }, thickness: 0.5, color: RULE });
    p.drawText(w.clean(`${rx.rx_number}  |  Page ${i + 1} of ${total}`), { x: MARGIN, y: MARGIN + 12, size: 8, font: regular, color: GRAY });
    const note = "Valid only when issued and signed by the prescribing doctor.";
    p.drawText(note, { x: MARGIN, y: MARGIN, size: 7.5, font: italic, color: GRAY });
    const brand = "Generated with MEDICO";
    p.drawText(brand, { x: PAGE_W - MARGIN - regular.widthOfTextAtSize(brand, 8), y: MARGIN + 12, size: 8, font: regular, color: GRAY });
  });

  const bytes = await doc.save();
  return { bytes, pageCount: total, warnings: [...w.warnings] };
}
