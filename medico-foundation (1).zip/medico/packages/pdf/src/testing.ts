import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

export interface ParsedPdf {
  pageCount: number;
  pageSizes: Array<{ width: number; height: number }>;
  pages: string[];
  text: string;
  title: string | undefined;
}

/** Open PDF bytes with an independent reader (pdf.js) and extract the text of every page. */
export async function readPdf(bytes: Uint8Array): Promise<ParsedPdf> {
  const loading = getDocument({ data: new Uint8Array(bytes), verbosity: 0 });
  const doc = await loading.promise;
  try {
    const pages: string[] = [];
    const pageSizes: ParsedPdf["pageSizes"] = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      const [x0, y0, x1, y1] = page.view;
      pageSizes.push({ width: (x1 ?? 0) - (x0 ?? 0), height: (y1 ?? 0) - (y0 ?? 0) });
      const content = await page.getTextContent();
      pages.push(content.items.map((it) => ("str" in it ? it.str : "")).join(" ").replace(/\s+/g, " "));
    }
    const meta = await doc.getMetadata();
    const info = meta.info as { Title?: string };
    return { pageCount: doc.numPages, pageSizes, pages, text: pages.join("\n"), title: info.Title };
  } finally {
    await loading.destroy();
  }
}
