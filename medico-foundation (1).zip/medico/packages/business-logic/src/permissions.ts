import type { ClinicRole } from "../../types/src/index.ts";

/**
 * UI-side view of what each role may do. This exists so screens can hide or disable controls.
 * It is NOT a security boundary: the database (Row Level Security) is. A cross-check test in
 * packages/db-tests runs each action against the real database to prove this table matches it.
 */
export type Action =
  | "clinical:read"
  | "patient:write"
  | "appointment:write"
  | "encounter:write"
  | "prescription:create"
  | "prescription:amend"
  | "medicine:manage"
  | "member:manage"
  | "clinic:update"
  | "audit:read";

const matrix: Record<ClinicRole, ReadonlySet<Action>> = {
  owner: new Set<Action>([
    "clinical:read", "patient:write", "appointment:write", "encounter:write", "prescription:create",
    "prescription:amend", "medicine:manage", "member:manage", "clinic:update", "audit:read",
  ]),
  doctor: new Set<Action>([
    "clinical:read", "patient:write", "appointment:write", "encounter:write", "prescription:create",
    "prescription:amend", "medicine:manage",
  ]),
  assistant: new Set<Action>(["clinical:read", "patient:write", "appointment:write"]),
  readonly: new Set<Action>(["clinical:read"]),
};

export const ALL_ACTIONS: readonly Action[] = Array.from(matrix.owner);
export const ALL_ROLES: readonly ClinicRole[] = ["owner", "doctor", "assistant", "readonly"];

export function can(role: ClinicRole | null | undefined, action: Action): boolean {
  if (!role) return false;
  return matrix[role].has(action);
}
