import type { FieldIssue, MedicationLine, PrescriptionStatus } from "../../types/src/index.ts";

export interface DraftPrescription {
  status: PrescriptionStatus;
  patient_id?: string | null;
  diagnosis?: string | null;
  medications: Array<Partial<MedicationLine> & { name?: string | null }>;
}

const blank = (v: unknown) => v === undefined || v === null || String(v).trim() === "";

/**
 * Checks a draft before the doctor finalizes it.
 *  - "error" issues block finalization (the database enforces the first two as well).
 *  - "warning" issues ask the doctor to confirm; MEDICO never fills in missing clinical details.
 */
export function validateForFinalization(rx: DraftPrescription): FieldIssue[] {
  const issues: FieldIssue[] = [];
  if (rx.status !== "draft") {
    issues.push({ field: "status", message: "Only a draft can be finalized", severity: "error" });
  }
  if (blank(rx.patient_id)) {
    issues.push({ field: "patient_id", message: "Select a patient", severity: "error" });
  }
  if (rx.medications.length === 0) {
    issues.push({ field: "medications", message: "Add at least one medication", severity: "error" });
  }
  rx.medications.forEach((m, i) => {
    const row = `medications[${i}]`;
    if (blank(m.name)) {
      issues.push({ field: `${row}.name`, message: `Medication ${i + 1}: name is required`, severity: "error" });
    }
    for (const [key, label] of [["dose", "dose"], ["frequency", "frequency"], ["duration", "duration"]] as const) {
      if (blank(m[key])) {
        issues.push({ field: `${row}.${key}`, message: `Medication ${i + 1}: ${label} is empty. Confirm this is intentional`, severity: "warning" });
      }
    }
  });
  if (blank(rx.diagnosis)) {
    issues.push({ field: "diagnosis", message: "No diagnosis entered", severity: "warning" });
  }
  return issues;
}

export const hasBlockingIssues = (issues: FieldIssue[]) => issues.some((i) => i.severity === "error");

/** Move one medication row and renumber positions 1..n (mirrors the editable list in the UI). */
export function reorderMedications<T extends { position: number }>(rows: readonly T[], from: number, to: number): T[] {
  if (from < 0 || from >= rows.length || to < 0 || to >= rows.length) {
    throw new RangeError("reorder index out of range");
  }
  const copy = [...rows].sort((a, b) => a.position - b.position);
  const [moved] = copy.splice(from, 1);
  copy.splice(to, 0, moved as T);
  return copy.map((r, i) => ({ ...r, position: i + 1 }));
}

/** "35 y" style age for display; returns null when the date of birth is unknown or invalid. */
export function formatAge(dateOfBirth: string | null | undefined, now: Date = new Date()): string | null {
  if (!dateOfBirth) return null;
  const dob = new Date(`${dateOfBirth}T00:00:00Z`);
  if (Number.isNaN(dob.getTime()) || dob.getTime() > now.getTime()) return null;
  let years = now.getUTCFullYear() - dob.getUTCFullYear();
  let months = now.getUTCMonth() - dob.getUTCMonth();
  if (now.getUTCDate() < dob.getUTCDate()) months -= 1;
  if (months < 0) { years -= 1; months += 12; }
  if (years >= 2) return `${years} y`;
  const totalMonths = years * 12 + months;
  return totalMonths >= 1 ? `${totalMonths} mo` : "< 1 mo";
}
