import { describe, test } from "node:test";
import assert from "node:assert/strict";
import { can, ALL_ACTIONS, ALL_ROLES, validateForFinalization, hasBlockingIssues, reorderMedications, formatAge } from "./index.ts";
import { validatePatientInput } from "../../types/src/index.ts";

describe("permissions", () => {
  test("missing role can do nothing", () => {
    for (const a of ALL_ACTIONS) assert.equal(can(null, a), false);
    assert.equal(can(undefined, "clinical:read"), false);
  });
  test("every role can read; only prescribers can prescribe; only owners manage members", () => {
    for (const r of ALL_ROLES) assert.equal(can(r, "clinical:read"), true);
    assert.deepEqual(ALL_ROLES.filter((r) => can(r, "prescription:create")), ["owner", "doctor"]);
    assert.deepEqual(ALL_ROLES.filter((r) => can(r, "member:manage")), ["owner"]);
    assert.deepEqual(ALL_ROLES.filter((r) => can(r, "patient:write")), ["owner", "doctor", "assistant"]);
  });
});

describe("validateForFinalization", () => {
  const ok = { status: "draft" as const, patient_id: "p1", diagnosis: "Fever",
    medications: [{ name: "Paracetamol", dose: "1 tablet", frequency: "TDS", duration: "3 days" }] };

  test("a complete draft has no issues", () => {
    assert.deepEqual(validateForFinalization(ok), []);
  });
  test("blocks an empty medication list, missing patient and non-draft status", () => {
    const issues = validateForFinalization({ status: "finalized", medications: [] });
    assert.ok(hasBlockingIssues(issues));
    assert.deepEqual(issues.filter((i) => i.severity === "error").map((i) => i.field).sort(), ["medications", "patient_id", "status"]);
  });
  test("a nameless medication blocks; missing dose/frequency/duration only warn and are never auto-filled", () => {
    const issues = validateForFinalization({ ...ok, medications: [{ name: " " }, { name: "Cetirizine" }] });
    assert.equal(issues.filter((i) => i.severity === "error").length, 1);
    assert.equal(issues.filter((i) => i.severity === "warning").length, 6 /* 3 per medication, none invented */);
  });
});

describe("reorderMedications", () => {
  const rows = [{ position: 1, name: "A" }, { position: 2, name: "B" }, { position: 3, name: "C" }];
  test("moves a row and renumbers", () => {
    assert.deepEqual(reorderMedications(rows, 0, 2).map((r) => `${r.position}${r.name}`), ["1B", "2C", "3A"]);
    assert.deepEqual(reorderMedications(rows, 2, 0).map((r) => `${r.position}${r.name}`), ["1C", "2A", "3B"]);
  });
  test("does not mutate the input and rejects bad indexes", () => {
    reorderMedications(rows, 0, 1);
    assert.equal(rows[0]!.name, "A");
    assert.throws(() => reorderMedications(rows, 0, 5), RangeError);
  });
});

describe("formatAge", () => {
  const now = new Date("2026-10-24T00:00:00Z");
  test("years, months and unknowns", () => {
    assert.equal(formatAge("1990-10-24", now), "36 y");
    assert.equal(formatAge("1990-10-25", now), "35 y");
    assert.equal(formatAge("2026-05-10", now), "5 mo");
    assert.equal(formatAge("2026-10-20", now), "< 1 mo");
    assert.equal(formatAge(null, now), null);
    assert.equal(formatAge("not-a-date", now), null);
    assert.equal(formatAge("2030-01-01", now), null);
  });
});

describe("validatePatientInput", () => {
  test("flags missing name, future birth date and bad sex", () => {
    const now = new Date("2026-10-24T00:00:00Z");
    const issues = validatePatientInput({ full_name: " ", date_of_birth: "2027-01-01", sex: "x" }, now);
    assert.deepEqual(issues.map((i) => i.field).sort(), ["date_of_birth", "full_name", "sex"]);
    assert.deepEqual(validatePatientInput({ full_name: "Ayesha Khan", date_of_birth: "1990-01-01", sex: "female", phone: "+92 300 1234567" }, now), []);
  });
});
