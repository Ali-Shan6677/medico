import { describe, test, before, after } from "node:test";
import assert from "node:assert/strict";
import { failureOf } from "./harness.ts";
import { buildWorld, World, countOf, affected, newDraft, addMed } from "./world.ts";

let w: World;
before(() => { w = buildWorld(); });
after(() => w.db.drop());

const alice = () => ({ as: w.alice });
const appt = (doctor: string, startOffset: string, endOffset: string, actor = w.alice, status = "scheduled") =>
  `insert into appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, status, created_by)
   values ('${w.A}', '${w.patientA}', '${doctor}', timestamptz '2030-01-01 09:00+00' + interval '${startOffset}',
           timestamptz '2030-01-01 09:00+00' + interval '${endOffset}', '${status}', '${actor}')`;

describe("patients", () => {
  test("patient numbers are generated per clinic and never repeat", () => {
    assert.equal(w.db.scalar(`select patient_no from patients where id = '${w.patientA}'`), "P-000001");
    assert.equal(w.db.scalar(`select patient_no from patients where id = '${w.patientB}'`), "P-000001");
    const second = w.db.scalar(`insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'Second', '${w.alice}') returning patient_no`, alice());
    assert.equal(second, "P-000002");
  });

  test("a duplicate patient number inside a clinic is rejected, but the same number is fine in another clinic", () => {
    assert.match(failureOf(w.db.run(
      `insert into patients (clinic_id, patient_no, full_name, created_by) values ('${w.A}', 'P-000001', 'Dup', '${w.alice}')`, alice())), /unique|duplicate/);
    w.db.must(`insert into patients (clinic_id, patient_no, full_name, created_by) values ('${w.B}', 'MANUAL-1', 'Manual', '${w.bob}')`, { as: w.bob });
  });

  test("invalid data is rejected by the database", () => {
    assert.match(failureOf(w.db.run(
      `insert into patients (clinic_id, full_name, created_by) values ('${w.A}', '   ', '${w.alice}')`, alice())), /check/);
    assert.match(failureOf(w.db.run(
      `insert into patients (clinic_id, full_name, date_of_birth, created_by) values ('${w.A}', 'Future', current_date + 1, '${w.alice}')`, alice())), /check/);
    assert.match(failureOf(w.db.run(
      `insert into patients (clinic_id, full_name, sex, created_by) values ('${w.A}', 'Bad Sex', 'robot', '${w.alice}')`, alice())), /check/);
  });

  test("a patient can be archived and stays readable", () => {
    const id = w.db.scalar(`insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'To Archive', '${w.alice}') returning id`, alice());
    assert.equal(affected(w.db, `update patients set archived_at = now() where id = '${id}'`, alice()), 1);
    assert.equal(countOf(w.db, `select 1 from patients where id = '${id}' and archived_at is not null`, alice()), 1);
  });

  test("patients can be found by name fragment and by phone", () => {
    assert.equal(countOf(w.db, `select 1 from patients where lower(full_name) like '%ayesha%'`, alice()), 1);
    assert.equal(countOf(w.db, `select 1 from patients where phone = '+92 311 1111111'`, alice()), 1);
  });

  test("allergies attach only to a patient of the same clinic", () => {
    w.db.must(`insert into patient_allergies (clinic_id, patient_id, substance, reaction) values ('${w.A}', '${w.patientA}', 'Penicillin', 'Rash')`, alice());
    assert.match(failureOf(w.db.run(
      `insert into patient_allergies (clinic_id, patient_id, substance) values ('${w.B}', '${w.patientA}', 'Penicillin')`, { as: w.bob })), /foreign key/);
    assert.equal(countOf(w.db, `select 1 from patient_allergies`, { as: w.bob }), 0);
  });
});

describe("appointments", () => {
  test("overlapping appointments for the same doctor are rejected", () => {
    w.db.must(appt(w.alice, "0 minutes", "30 minutes"), alice());
    assert.match(failureOf(w.db.run(appt(w.alice, "15 minutes", "45 minutes"), alice())), /conflicting key|exclusion/);
    assert.match(failureOf(w.db.run(appt(w.alice, "-10 minutes", "10 minutes"), alice())), /conflicting key|exclusion/);
  });

  test("back-to-back appointments are allowed, and so are overlaps for a different doctor", () => {
    w.db.must(appt(w.alice, "30 minutes", "60 minutes"), alice());
    w.db.must(appt(w.doc2, "0 minutes", "30 minutes"), alice());
  });

  test("a cancelled appointment frees the slot", () => {
    assert.equal(affected(w.db,
      `update appointments set status = 'cancelled' where doctor_id = '${w.alice}' and starts_at = timestamptz '2030-01-01 09:00+00'`, alice()), 1);
    w.db.must(appt(w.alice, "5 minutes", "25 minutes"), alice());
  });

  test("an appointment must end after it starts", () => {
    assert.match(failureOf(w.db.run(appt(w.alice, "5 hours", "4 hours"), alice())), /check/);
  });

  test("appointments can be rescheduled, but not into a conflict", () => {
    w.db.must(appt(w.alice, "3 hours", "3 hours 30 minutes"), alice());
    const id = w.db.scalar(`select id from appointments where doctor_id = '${w.alice}' and starts_at = timestamptz '2030-01-01 12:00+00'`);
    assert.equal(affected(w.db, `update appointments set starts_at = starts_at + interval '1 hour', ends_at = ends_at + interval '1 hour' where id = '${id}'`, alice()), 1);
    assert.match(failureOf(w.db.run(
      `update appointments set starts_at = timestamptz '2030-01-01 09:10+00', ends_at = timestamptz '2030-01-01 09:20+00' where id = '${id}'`, alice())), /conflicting key|exclusion/);
  });

  test("follow-up reminders can be created and completed by staff, but not by read-only users", () => {
    const id = w.db.scalar(
      `insert into followups (clinic_id, patient_id, due_at, note, created_by) values ('${w.A}', '${w.patientA}', now() + interval '7 days', 'Review labs', '${w.carol}') returning id`, { as: w.carol });
    assert.equal(affected(w.db, `update followups set status = 'done' where id = '${id}'`, { as: w.carol }), 1);
    assert.match(failureOf(w.db.run(
      `insert into followups (clinic_id, patient_id, due_at, created_by) values ('${w.A}', '${w.patientA}', now(), '${w.dan}')`, { as: w.dan })), /row-level security/);
  });
});

describe("encounters", () => {
  test("a finalized consultation is immutable and cannot be deleted", () => {
    const id = w.db.scalar(
      `insert into encounters (clinic_id, patient_id, doctor_id, presenting_complaint) values ('${w.A}', '${w.patientA}', '${w.alice}', 'Headache') returning id`, alice());
    assert.equal(affected(w.db, `update encounters set diagnosis = 'Tension headache' where id = '${id}'`, alice()), 1);
    assert.equal(affected(w.db, `update encounters set status = 'finalized' where id = '${id}'`, alice()), 1);
    assert.equal(affected(w.db, `update encounters set diagnosis = 'changed later' where id = '${id}'`, alice()), 0);
    assert.equal(affected(w.db, `delete from encounters where id = '${id}'`, alice()), 0);
    assert.match(failureOf(w.db.run(`update encounters set diagnosis = 'admin edit' where id = '${id}'`)), /immutable/);
    assert.equal(w.db.scalar(`select diagnosis from encounters where id = '${id}'`), "Tension headache");
  });
});

describe("clinic membership rules", () => {
  test("a clinic cannot lose its last owner", () => {
    assert.match(failureOf(w.db.run(`update clinic_members set role = 'doctor' where user_id = '${w.bob}'`, { as: w.bob })), /at least one active owner/);
    assert.match(failureOf(w.db.run(`delete from clinic_members where user_id = '${w.bob}'`, { as: w.bob })), /at least one active owner/);
    assert.match(failureOf(w.db.run(`update clinic_members set status = 'suspended' where user_id = '${w.bob}'`, { as: w.bob })), /at least one active owner/);
  });

  test("ownership can be handed over, after which the former owner can step down", () => {
    w.db.must(`update clinic_members set role = 'owner' where user_id = '${w.doc2}' and clinic_id = '${w.A}'`, alice());
    w.db.must(`update clinic_members set role = 'doctor' where user_id = '${w.alice}' and clinic_id = '${w.A}'`, alice());
    assert.equal(w.db.scalar(`select role from clinic_members where user_id = '${w.alice}' and clinic_id = '${w.A}'`), "doctor");
    // restore for later tests
    w.db.must(`update clinic_members set role = 'owner' where user_id = '${w.alice}' and clinic_id = '${w.A}'`, { as: w.doc2 });
  });

  test("a clinic that holds finalized medical records cannot be deleted", () => {
    const rx = newDraft(w, { clinic: w.B, patient: w.patientB, doctor: w.bob });
    addMed(w, rx, 1, "Paracetamol", w.bob, w.B);
    w.db.must(`select finalize_prescription('${rx}')`, { as: w.bob });
    assert.match(failureOf(w.db.run(`delete from clinics where id = '${w.B}'`)), /foreign key|cannot be deleted|append-only/);
    assert.equal(w.db.scalar(`select count(*) from clinics where id = '${w.B}'`), "1");
  });
});

describe("audit trail", () => {
  test("changes are recorded with actor, entity and changed column names but never the values", () => {
    const id = w.db.scalar(`insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'Audit Subject', '${w.alice}') returning id`, alice());
    w.db.must(`update patients set phone = '+92 399 9999999', address = 'Secret Street 1' where id = '${id}'`, alice());

    const rows = w.db.must(
      `select action, entity, actor_id, coalesce(array_to_string(changed_columns, ','), '') from audit_events where entity_id = '${id}' order by id`, alice());
    assert.deepEqual(rows.map((r) => r[0]), ["insert", "update"]);
    assert.ok(rows.every((r) => r[1] === "patients" && r[2] === w.alice));
    assert.equal(rows[1]![3], "address,phone");

    const dump = w.db.scalar(`select string_agg(audit_events::text, ' ') from audit_events`);
    assert.ok(!dump.includes("Secret Street"), "audit log must not store field values");
    assert.ok(!dump.includes("9999999"), "audit log must not store field values");
  });

  test("prescription finalization and member changes are audited", () => {
    const rx = newDraft(w);
    addMed(w, rx, 1, "Paracetamol");
    w.db.must(`select finalize_prescription('${rx}')`, alice());
    const cols = w.db.scalar(`select array_to_string(changed_columns, ',') from audit_events where entity = 'prescriptions' and entity_id = '${rx}' and action = 'update'`, alice());
    assert.match(cols, /status/);
    assert.ok(countOf(w.db, `select 1 from audit_events where entity = 'clinic_members' and clinic_id = '${w.A}'`, alice()) > 0);
  });

  test("an UPDATE that changes nothing leaves no audit noise", () => {
    const before_ = Number(w.db.scalar(`select count(*) from audit_events`));
    w.db.must(`update patients set phone = phone where id = '${w.patientA}'`, alice());
    assert.equal(Number(w.db.scalar(`select count(*) from audit_events`)), before_);
  });
});

describe("medicine catalogue", () => {
  before(() => {
    w.db.must(
      `insert into medicines (clinic_id, generic_name, brand_name, strength, dosage_form, category, source, verified, data_source_note) values
        (null, 'Paracetamol', 'SampleFever', '500 mg', 'Tablet', 'Analgesic', 'sample', false, 'fictional sample data'),
        (null, 'Amoxicillin', 'SampleCillin', '250 mg', 'Capsule', 'Antibiotic', 'sample', false, 'fictional sample data'),
        (null, 'Cetirizine', 'SampleAllergy', '10 mg', 'Tablet', 'Antihistamine', 'sample', false, 'fictional sample data')`);
  });

  test("search by generic or brand name, case-insensitive and partial", () => {
    const search = (q: string) => w.db.must(
      `select generic_name from medicines where lower(generic_name || ' ' || coalesce(brand_name, '')) like lower('%${q}%') order by 1`, alice()).map((r) => r[0]);
    assert.deepEqual(search("PARAC"), ["Paracetamol"]);
    assert.deepEqual(search("samplecillin"), ["Amoxicillin"]);
    assert.deepEqual(search("zzz"), []);
  });

  test("fuzzy matching tolerates typos", () => {
    const r = w.db.must(
      `select generic_name from medicines where clinic_id is null and similarity(lower(generic_name), 'paracetmol') > 0.3 order by 1`, alice());
    assert.deepEqual(r.map((x) => x[0]), ["Paracetamol"]);
  });

  test("clients cannot modify the shared catalogue or mark an entry verified", () => {
    assert.match(failureOf(w.db.run(`insert into medicines (clinic_id, generic_name, source, verified) values (null, 'Fake Drug', 'licensed_import', true)`, alice())), /row-level security/);
    assert.equal(affected(w.db, `update medicines set strength = '1 g' where clinic_id is null`, alice()), 0);
    assert.equal(affected(w.db, `delete from medicines where clinic_id is null`, alice()), 0);
    assert.match(failureOf(w.db.run(`insert into medicines (clinic_id, generic_name, source, verified) values ('${w.A}', 'Mine', 'user', true)`, alice())), /row-level security|check/);
    assert.match(failureOf(w.db.run(`insert into medicines (clinic_id, generic_name, source) values ('${w.A}', 'Mine', 'sample')`, alice())), /row-level security/);
  });

  test("personal entries are clinic-scoped and duplicates are rejected", () => {
    w.db.must(`insert into medicines (clinic_id, generic_name, strength, source) values ('${w.A}', 'House Syrup', '5 ml', 'user')`, alice());
    assert.match(failureOf(w.db.run(`insert into medicines (clinic_id, generic_name, strength, source) values ('${w.A}', 'house syrup', '5 ML', 'user')`, alice())), /duplicate|unique/);
    w.db.must(`insert into medicines (clinic_id, generic_name, strength, source) values ('${w.B}', 'House Syrup', '5 ml', 'user')`, { as: w.bob });
    assert.equal(countOf(w.db, `select 1 from medicines where generic_name = 'House Syrup'`, alice()), 1);
  });

  test("favorites are private to each user", () => {
    const med = w.db.scalar(`select id from medicines where generic_name = 'Paracetamol' and clinic_id is null`);
    w.db.must(`insert into medicine_favorites (user_id, medicine_id) values ('${w.alice}', '${med}')`, alice());
    assert.equal(countOf(w.db, `select 1 from medicine_favorites`, alice()), 1);
    assert.equal(countOf(w.db, `select 1 from medicine_favorites`, { as: w.doc2 }), 0);
    assert.match(failureOf(w.db.run(`insert into medicine_favorites (user_id, medicine_id) values ('${w.alice}', '${med}')`, { as: w.doc2 })), /row-level security/);
  });
});
