import { describe, test, before, after } from "node:test";
import assert from "node:assert/strict";
import { failureOf } from "./harness.ts";
import { buildWorld, World, countOf, affected, newDraft, addMed } from "./world.ts";

let w: World;
let rxA: string; // finalized prescription in clinic A

before(() => {
  w = buildWorld();
  rxA = newDraft(w);
  addMed(w, rxA, 1, "Paracetamol");
  w.db.must(`select finalize_prescription('${rxA}')`, { as: w.alice });
  w.db.must(
    `insert into appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, created_by)
     values ('${w.A}', '${w.patientA}', '${w.alice}', now() + interval '1 day', now() + interval '1 day 30 minutes', '${w.alice}')`,
    { as: w.alice },
  );
});
after(() => w.db.drop());

describe("cross-clinic isolation (another clinic's doctor)", () => {
  const bob = () => ({ as: w.bob });

  test("cannot list or fetch patients of another clinic, even by exact id", () => {
    assert.equal(countOf(w.db, `select 1 from patients where clinic_id = '${w.A}'`, bob()), 0);
    assert.equal(countOf(w.db, `select 1 from patients where id = '${w.patientA}'`, bob()), 0);
    assert.equal(countOf(w.db, `select 1 from patients`, bob()), 1); // only his own patient
  });

  test("cannot insert a patient into another clinic", () => {
    const r = w.db.run(
      `insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'Injected', '${w.bob}')`, bob());
    assert.match(failureOf(r), /row-level security/);
  });

  test("cannot update another clinic's patient (zero rows affected)", () => {
    assert.equal(affected(w.db, `update patients set phone = '000' where id = '${w.patientA}'`, bob()), 0);
    assert.equal(w.db.scalar(`select phone from patients where id = '${w.patientA}'`), "+92 311 1111111");
  });

  test("cannot read prescriptions, medications, versions, appointments or audit of another clinic", () => {
    for (const t of ["prescriptions", "prescription_medications", "prescription_versions", "appointments", "audit_events", "encounters", "followups"]) {
      assert.equal(countOf(w.db, `select 1 from ${t} where clinic_id = '${w.A}'`, bob()), 0, t);
    }
  });

  test("cannot create a prescription inside another clinic", () => {
    const r = w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${w.bob}')`, bob());
    assert.match(failureOf(r), /row-level security/);
  });

  test("cannot attach a prescription in his own clinic to another clinic's patient", () => {
    const r = w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.B}', '${w.patientA}', '${w.bob}')`, bob());
    assert.match(failureOf(r), /foreign key/);
  });

  test("cannot book an appointment for another clinic's patient", () => {
    const r = w.db.run(
      `insert into appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, created_by)
       values ('${w.B}', '${w.patientA}', '${w.bob}', now() + interval '2 day', now() + interval '2 day 1 hour', '${w.bob}')`, bob());
    assert.match(failureOf(r), /foreign key/);
  });

  test("cannot amend another clinic's finalized prescription", () => {
    const r = w.db.run(`select amend_prescription('${rxA}', 'malicious')`, bob());
    assert.match(failureOf(r), /not found or not permitted/);
  });

  test("cannot add himself to another clinic or promote himself", () => {
    const r = w.db.run(`insert into clinic_members (clinic_id, user_id, role) values ('${w.A}', '${w.bob}', 'owner')`, bob());
    assert.match(failureOf(r), /row-level security/);
    assert.equal(affected(w.db, `update clinic_members set role = 'owner' where clinic_id = '${w.A}'`, bob()), 0);
  });

  test("cannot see another clinic, its members, or its staff profiles", () => {
    assert.equal(countOf(w.db, `select 1 from clinics where id = '${w.A}'`, bob()), 0);
    assert.equal(countOf(w.db, `select 1 from clinic_members where clinic_id = '${w.A}'`, bob()), 0);
    assert.equal(countOf(w.db, `select 1 from profiles where id = '${w.alice}'`, bob()), 0);
    assert.equal(affected(w.db, `update clinics set name = 'pwned' where id = '${w.A}'`, bob()), 0);
  });

  test("cannot see another clinic's private medicine entries but does see the shared catalogue", () => {
    w.db.must(`insert into medicines (clinic_id, generic_name, source) values ('${w.A}', 'Secret Mix', 'user')`, { as: w.alice });
    w.db.must(`insert into medicines (clinic_id, generic_name, source, data_source_note) values (null, 'Paracetamol', 'sample', 'fictional sample')`);
    assert.equal(countOf(w.db, `select 1 from medicines where generic_name = 'Secret Mix'`, bob()), 0);
    assert.equal(countOf(w.db, `select 1 from medicines where generic_name = 'Paracetamol'`, bob()), 1);
  });
});

describe("users with no clinic and unauthenticated clients", () => {
  test("an authenticated user without a clinic sees nothing", () => {
    for (const t of ["clinics", "patients", "prescriptions", "appointments", "clinic_members"]) {
      assert.equal(countOf(w.db, `select 1 from ${t}`, { as: w.eve }), 0, t);
    }
  });

  test("anon role has no access to any clinical table", () => {
    for (const t of ["patients", "prescriptions", "profiles", "clinics", "audit_events", "medicines"]) {
      assert.match(failureOf(w.db.run(`select 1 from ${t}`, { anon: true })), /permission denied/, t);
    }
  });

  test("a request with no user id (null auth.uid) sees nothing and cannot create a clinic", () => {
    assert.equal(countOf(w.db, `select 1 from patients`, { as: "00000000-0000-0000-0000-000000000000" }), 0);
    assert.match(failureOf(w.db.run(`select create_clinic('No Auth')`, { anon: true })), /permission denied/);
  });
});

describe("role permissions inside one clinic", () => {
  test("read-only staff can read but not write clinical data", () => {
    const dan = { as: w.dan };
    assert.ok(countOf(w.db, `select 1 from patients where id = '${w.patientA}'`, dan) === 1);
    assert.equal(countOf(w.db, `select 1 from prescriptions`, dan), 1);
    assert.match(failureOf(w.db.run(
      `insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'X', '${w.dan}')`, dan)), /row-level security/);
    assert.equal(affected(w.db, `update patients set phone = '1' where id = '${w.patientA}'`, dan), 0);
    assert.match(failureOf(w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${w.dan}')`, dan)), /row-level security/);
    assert.match(failureOf(w.db.run(
      `insert into appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, created_by)
       values ('${w.A}', '${w.patientA}', '${w.alice}', now() + interval '3 day', now() + interval '3 day 1 hour', '${w.dan}')`, dan)), /row-level security/);
  });

  test("an assistant can manage patients and appointments but cannot prescribe or write encounters", () => {
    const carol = { as: w.carol };
    w.db.must(`insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'Walk In', '${w.carol}')`, carol);
    assert.equal(affected(w.db, `update patients set phone = '0300' where full_name = 'Walk In'`, carol), 1);
    w.db.must(
      `insert into appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, created_by)
       values ('${w.A}', '${w.patientA}', '${w.doc2}', now() + interval '4 day', now() + interval '4 day 30 minutes', '${w.carol}')`, carol);
    assert.match(failureOf(w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${w.carol}')`, carol)), /row-level security/);
    assert.match(failureOf(w.db.run(
      `insert into encounters (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${w.carol}')`, carol)), /row-level security/);
  });

  test("a doctor cannot forge another doctor as the author", () => {
    const r = w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${w.alice}')`, { as: w.doc2 });
    assert.match(failureOf(r), /row-level security/);
  });

  test("a second doctor can read but not edit or delete the first doctor's draft", () => {
    const draft = newDraft(w, { diagnosis: "Cough" });
    assert.equal(countOf(w.db, `select 1 from prescriptions where id = '${draft}'`, { as: w.doc2 }), 1);
    assert.equal(affected(w.db, `update prescriptions set diagnosis = 'tampered' where id = '${draft}'`, { as: w.doc2 }), 0);
    assert.equal(affected(w.db, `delete from prescriptions where id = '${draft}'`, { as: w.doc2 }), 0);
    assert.match(failureOf(w.db.run(
      `insert into prescription_medications (clinic_id, prescription_id, position, name) values ('${w.A}', '${draft}', 9, 'Injected')`,
      { as: w.doc2 })), /row-level security/);
    assert.equal(w.db.scalar(`select diagnosis from prescriptions where id = '${draft}'`), "Cough");
  });

  test("only the owner can manage members; a doctor and an assistant cannot", () => {
    for (const actor of [w.doc2, w.carol]) {
      assert.match(failureOf(w.db.run(
        `insert into clinic_members (clinic_id, user_id, role) values ('${w.A}', '${w.eve}', 'readonly')`, { as: actor })), /row-level security/);
      assert.equal(affected(w.db, `update clinic_members set role = 'owner' where user_id = '${actor}'`, { as: actor }), 0);
      assert.equal(affected(w.db, `delete from clinic_members where user_id = '${w.dan}'`, { as: actor }), 0);
    }
  });

  test("a suspended member immediately loses all access", () => {
    const frank = w.db.addUser("Frank Temp");
    w.db.must(`insert into clinic_members (clinic_id, user_id, role) values ('${w.A}', '${frank}', 'doctor')`, { as: w.alice });
    assert.equal(countOf(w.db, `select 1 from patients where id = '${w.patientA}'`, { as: frank }), 1);
    w.db.must(`update clinic_members set status = 'suspended' where user_id = '${frank}'`, { as: w.alice });
    assert.equal(countOf(w.db, `select 1 from patients`, { as: frank }), 0);
    assert.match(failureOf(w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${frank}')`, { as: frank })), /row-level security/);
  });
});

describe("server-managed tables cannot be written by clients", () => {
  test("clients cannot write the audit log, prescription versions or counters", () => {
    const alice = { as: w.alice };
    assert.match(failureOf(w.db.run(`insert into audit_events (action, entity) values ('x', 'y')`, alice)), /permission denied/);
    assert.match(failureOf(w.db.run(`delete from audit_events`, alice)), /permission denied/);
    assert.match(failureOf(w.db.run(`update prescription_versions set reason = 'edited'`, alice)), /permission denied/);
    assert.match(failureOf(w.db.run(`delete from prescription_versions`, alice)), /permission denied/);
    assert.match(failureOf(w.db.run(`select * from clinic_counters`, alice)), /permission denied/);
    assert.match(failureOf(w.db.run(`select next_counter('${w.A}', 'patient')`, alice)), /permission denied/);
  });

  test("clients cannot delete patients (records are archived, not deleted)", () => {
    assert.match(failureOf(w.db.run(`delete from patients where id = '${w.patientA}'`, { as: w.alice })), /permission denied/);
  });

  test("only the clinic owner can read the audit log", () => {
    assert.ok(countOf(w.db, `select 1 from audit_events`, { as: w.alice }) > 0);
    for (const u of [w.doc2, w.carol, w.dan, w.bob]) {
      assert.equal(countOf(w.db, `select 1 from audit_events where clinic_id = '${w.A}'`, { as: u }), 0);
    }
  });
});
