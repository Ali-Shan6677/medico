import { describe, test, before, after } from "node:test";
import assert from "node:assert/strict";
import { failureOf } from "./harness.ts";
import { buildWorld, World, countOf, affected, newDraft, addMed } from "./world.ts";

let w: World;
before(() => { w = buildWorld(); });
after(() => w.db.drop());

const alice = () => ({ as: w.alice });

describe("draft prescriptions", () => {
  test("numbers are assigned automatically, are unique, and count per clinic", () => {
    const a1 = newDraft(w);
    const a2 = newDraft(w);
    const b1 = newDraft(w, { clinic: w.B, patient: w.patientB, doctor: w.bob });
    const n = (id: string) => w.db.scalar(`select rx_number from prescriptions where id = '${id}'`);
    assert.match(n(a1), /^RX-\d{6}$/);
    assert.notEqual(n(a1), n(a2));
    assert.equal(n(a2), `RX-${String(Number(n(a1).slice(3)) + 1).padStart(6, "0")}`);
    assert.equal(n(b1), "RX-000001"); // clinic B has its own sequence
  });

  test("a draft can be edited, medications added, edited, reordered and removed", () => {
    const rx = newDraft(w);
    const m1 = addMed(w, rx, 1, "Paracetamol");
    const m2 = addMed(w, rx, 2, "Amoxicillin");
    assert.equal(affected(w.db, `update prescriptions set diagnosis = 'Tonsillitis' where id = '${rx}'`, alice()), 1);
    assert.equal(affected(w.db, `update prescription_medications set dose = '2 tablets' where id = '${m1}'`, alice()), 1);

    // Swap positions in one statement (the unique constraint is deferred).
    w.db.must(`update prescription_medications set position = 3 - position where prescription_id = '${rx}'`, alice());
    assert.deepEqual(
      w.db.must(`select name from prescription_medications where prescription_id = '${rx}' order by position`).map((r) => r[0]),
      ["Amoxicillin", "Paracetamol"]);

    assert.equal(affected(w.db, `delete from prescription_medications where id = '${m2}'`, alice()), 1);
    assert.equal(countOf(w.db, `select 1 from prescription_medications where prescription_id = '${rx}'`, alice()), 1);
    assert.equal(affected(w.db, `delete from prescriptions where id = '${rx}'`, alice()), 1); // drafts may be discarded
  });

  test("two medications cannot share a position", () => {
    const rx = newDraft(w);
    addMed(w, rx, 1, "Paracetamol");
    const r = w.db.run(
      `insert into prescription_medications (clinic_id, prescription_id, position, name)
       values ('${w.A}', '${rx}', 1, 'Duplicate slot')`, alice());
    assert.match(failureOf(r), /unique|duplicate/);
  });

  test("identity fields of a draft cannot be changed", () => {
    const rx = newDraft(w);
    assert.match(failureOf(w.db.run(`update prescriptions set rx_number = 'RX-999999' where id = '${rx}'`, alice())), /identity fields/);
    assert.match(failureOf(w.db.run(`update prescriptions set patient_id = '${w.patientB}' where id = '${rx}'`, alice())), /identity fields|foreign key/);
  });

  test("a client cannot insert a prescription that is already finalized or that claims to amend another", () => {
    const rx = newDraft(w);
    addMed(w, rx, 1, "Paracetamol");
    w.db.must(`select finalize_prescription('${rx}')`, alice());
    assert.match(failureOf(w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id, status, finalized_at)
       values ('${w.A}', '${w.patientA}', '${w.alice}', 'finalized', now())`, alice())), /row-level security/);
    assert.match(failureOf(w.db.run(
      `insert into prescriptions (clinic_id, patient_id, doctor_id, amends_id, amendment_reason)
       values ('${w.A}', '${w.patientA}', '${w.alice}', '${rx}', 'sneaky')`, alice())), /row-level security/);
  });
});

describe("finalization", () => {
  test("cannot be finalized without any medication", () => {
    const rx = newDraft(w);
    assert.match(failureOf(w.db.run(`select finalize_prescription('${rx}')`, alice())), /at least one medication/);
    assert.match(failureOf(w.db.run(`update prescriptions set status = 'finalized' where id = '${rx}'`, alice())), /at least one medication/);
    assert.equal(w.db.scalar(`select status from prescriptions where id = '${rx}'`), "draft");
  });

  test("only the author can finalize", () => {
    const rx = newDraft(w);
    addMed(w, rx, 1, "Paracetamol");
    assert.match(failureOf(w.db.run(`select finalize_prescription('${rx}')`, { as: w.doc2 })), /not found, not a draft, or not permitted/);
    assert.match(failureOf(w.db.run(`select finalize_prescription('${rx}')`, { as: w.carol })), /not found, not a draft, or not permitted/);
    assert.equal(w.db.scalar(`select status from prescriptions where id = '${rx}'`), "draft");
  });

  test("finalizing records the time, locks the record and writes version 1 with a full snapshot", () => {
    const rx = newDraft(w, { diagnosis: "Acute pharyngitis" });
    addMed(w, rx, 1, "Paracetamol");
    addMed(w, rx, 2, "Cetirizine");
    w.db.must(`select finalize_prescription('${rx}')`, alice());

    const [status, finalized] = w.db.must(`select status, finalized_at is not null from prescriptions where id = '${rx}'`)[0]!;
    assert.equal(status, "finalized");
    assert.equal(finalized, "t");

    const versions = w.db.must(`select version_no, content::text from prescription_versions where prescription_id = '${rx}'`);
    assert.equal(versions.length, 1);
    const content = JSON.parse(versions[0]![1]!);
    assert.equal(content.patient.full_name, "Ayesha Khan");
    assert.equal(content.clinic.name, "Alice Clinic");
    assert.equal(content.doctor.full_name, "Dr Alice");
    assert.equal(content.diagnosis, "Acute pharyngitis");
    assert.deepEqual(content.medications.map((m: { name: string }) => m.name), ["Paracetamol", "Cetirizine"]);
  });

  test("a finalized prescription cannot be modified, reverted, or deleted by anyone", () => {
    const rx = newDraft(w);
    const med = addMed(w, rx, 1, "Paracetamol");
    w.db.must(`select finalize_prescription('${rx}')`, alice());

    // As the author (RLS already hides finalized rows from UPDATE, so no row is touched)...
    assert.equal(affected(w.db, `update prescriptions set diagnosis = 'changed' where id = '${rx}'`, alice()), 0);
    assert.equal(affected(w.db, `update prescriptions set status = 'draft', finalized_at = null where id = '${rx}'`, alice()), 0);
    assert.equal(affected(w.db, `delete from prescriptions where id = '${rx}'`, alice()), 0);
    assert.match(failureOf(w.db.run(`update prescription_medications set dose = '99' where id = '${med}'`, alice())), /cannot be changed/);
    assert.match(failureOf(w.db.run(`delete from prescription_medications where id = '${med}'`, alice())), /cannot be changed/);
    assert.match(failureOf(w.db.run(
      `insert into prescription_medications (clinic_id, prescription_id, position, name) values ('${w.A}', '${rx}', 2, 'Late addition')`,
      alice())), /cannot be changed|row-level security/);

    // ...and even a database administrator is stopped by the triggers.
    for (const stmt of [
      `update prescriptions set diagnosis = 'admin edit' where id = '${rx}'`,
      `update prescriptions set status = 'draft', finalized_at = null where id = '${rx}'`,
      `delete from prescriptions where id = '${rx}'`,
      `update prescription_medications set dose = '99' where id = '${med}'`,
      `delete from prescription_medications where id = '${med}'`,
      `insert into prescription_medications (clinic_id, prescription_id, position, name) values ('${w.A}', '${rx}', 5, 'Admin add')`,
      `update prescription_versions set reason = 'x' where prescription_id = '${rx}'`,
      `delete from prescription_versions where prescription_id = '${rx}'`,
    ]) {
      assert.match(failureOf(w.db.run(stmt)), /immutable|cannot be changed|cannot be deleted|append-only/, stmt);
    }
    assert.equal(w.db.scalar(`select diagnosis from prescriptions where id = '${rx}'`), "Viral fever");
  });

  test("a finalized prescription cannot be marked superseded directly", () => {
    const rx = newDraft(w);
    addMed(w, rx, 1, "Paracetamol");
    w.db.must(`select finalize_prescription('${rx}')`, alice());
    assert.match(failureOf(w.db.run(`update prescriptions set status = 'superseded' where id = '${rx}'`)), /immutable/);
  });

  test("the version snapshot keeps the original patient details after the patient record changes", () => {
    const patient = w.db.scalar(
      `insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'Original Name', '${w.alice}') returning id`, alice());
    const rx = newDraft(w, { patient });
    addMed(w, rx, 1, "Paracetamol");
    w.db.must(`select finalize_prescription('${rx}')`, alice());
    w.db.must(`update patients set full_name = 'Renamed Person' where id = '${patient}'`, alice());
    const content = JSON.parse(w.db.scalar(`select content::text from prescription_versions where prescription_id = '${rx}'`));
    assert.equal(content.patient.full_name, "Original Name");
  });
});

describe("amendments", () => {
  let original: string;
  let amendment: string;

  before(() => {
    original = newDraft(w, { diagnosis: "Gastritis" });
    addMed(w, original, 1, "Omeprazole");
    addMed(w, original, 2, "Antacid");
    w.db.must(`select finalize_prescription('${original}')`, alice());
  });

  test("a reason is required, and only finalized prescriptions can be amended", () => {
    assert.match(failureOf(w.db.run(`select amend_prescription('${original}', '   ')`, alice())), /reason is required/);
    const draft = newDraft(w);
    assert.match(failureOf(w.db.run(`select amend_prescription('${draft}', 'oops')`, alice())), /only a finalized prescription/);
  });

  test("assistants and read-only staff cannot amend", () => {
    for (const u of [w.carol, w.dan]) {
      assert.match(failureOf(w.db.run(`select amend_prescription('${original}', 'attempt')`, { as: u })), /not found or not permitted/);
    }
  });

  test("amending opens a new linked draft with copied medications and leaves the original untouched", () => {
    amendment = w.db.scalar(`select amend_prescription('${original}', 'Wrong dose of Omeprazole')`, { as: w.doc2 });
    const [rx, status, amends, reason, author] = w.db.must(
      `select rx_number, status, amends_id, amendment_reason, doctor_id from prescriptions where id = '${amendment}'`)[0]!;
    const originalRx = w.db.scalar(`select rx_number from prescriptions where id = '${original}'`);
    assert.equal(rx, `${originalRx}-A1`);
    assert.equal(status, "draft");
    assert.equal(amends, original);
    assert.equal(reason, "Wrong dose of Omeprazole");
    assert.equal(author, w.doc2); // the amending doctor becomes the author of the amendment
    assert.equal(countOf(w.db, `select 1 from prescription_medications where prescription_id = '${amendment}'`, alice()), 2);
    assert.equal(w.db.scalar(`select status from prescriptions where id = '${original}'`), "finalized");
    assert.equal(w.db.scalar(`select count(*) from prescription_versions where prescription_id = '${original}'`), "1");
  });

  test("only one open amendment may exist per prescription", () => {
    assert.match(failureOf(w.db.run(`select amend_prescription('${original}', 'second attempt')`, alice())), /unique|duplicate/);
  });

  test("editing the amendment draft does not change the original", () => {
    assert.equal(affected(w.db, `update prescription_medications set dose = '40 mg' where prescription_id = '${amendment}' and name = 'Omeprazole'`, { as: w.doc2 }), 1);
    assert.equal(w.db.scalar(`select dose from prescription_medications where prescription_id = '${original}' and name = 'Omeprazole'`), "1 tablet");
  });

  test("finalizing the amendment supersedes the original and records the full history", () => {
    w.db.must(`select finalize_prescription('${amendment}')`, { as: w.doc2 });
    assert.equal(w.db.scalar(`select status from prescriptions where id = '${original}'`), "superseded");
    assert.equal(w.db.scalar(`select status from prescriptions where id = '${amendment}'`), "finalized");

    const history = w.db.must(
      `select p.rx_number, p.status, v.version_no from prescriptions p
       join prescription_versions v on v.prescription_id = p.id
       where p.id in ('${original}', '${amendment}') order by p.rx_number`);
    assert.equal(history.length, 2);

    const orig = JSON.parse(w.db.scalar(`select content::text from prescription_versions where prescription_id = '${original}'`));
    const amend = JSON.parse(w.db.scalar(`select content::text from prescription_versions where prescription_id = '${amendment}'`));
    assert.equal(orig.medications[0].dose, "1 tablet"); // the original record is preserved as issued
    assert.equal(amend.medications.find((m: { name: string }) => m.name === "Omeprazole").dose, "40 mg");
    assert.equal(amend.amends_id, original);
    assert.equal(amend.amendment_reason, "Wrong dose of Omeprazole");
  });

  test("a superseded prescription cannot be amended or edited again", () => {
    assert.match(failureOf(w.db.run(`select amend_prescription('${original}', 'again')`, alice())), /only a finalized prescription/);
    assert.match(failureOf(w.db.run(`update prescriptions set diagnosis = 'x' where id = '${original}'`)), /immutable/);
  });

  test("the amendment itself can be amended, producing a -A2 style chain", () => {
    const second = w.db.scalar(`select amend_prescription('${amendment}', 'Frequency correction')`, alice());
    const rx = w.db.scalar(`select rx_number from prescriptions where id = '${second}'`);
    assert.match(rx, /-A1-A1$/);
  });
});
