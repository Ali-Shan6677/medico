import { spawnSync } from "node:child_process";
import { readFileSync, readdirSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(here, "../../..");

const HOST = process.env.MEDICO_PG_SOCK ?? "/tmp/medico-pg-sock";
const PORT = process.env.MEDICO_PG_PORT ?? "54329";
const SUPERUSER = process.env.MEDICO_PG_SUPERUSER ?? "claude";
const SEP = "\u001f";

export type Result = { ok: boolean; rows: string[][]; error: string };
export type Actor =
  | { as: string } // authenticated user with this id
  | { anon: true } // unauthenticated client
  | { admin: true }; // database owner / migrations (bypasses RLS)

function psql(db: string, script: string): Result {
  const r = spawnSync(
    "psql",
    ["-h", HOST, "-p", PORT, "-U", SUPERUSER, "-d", db, "-X", "-q", "-A", "-t", "-F", SEP,
     "-v", "ON_ERROR_STOP=1", "-f", "-"],
    { input: script, encoding: "utf8" },
  );
  const out = (r.stdout ?? "").trim();
  return {
    ok: r.status === 0,
    rows: out === "" ? [] : out.split("\n").map((line) => line.split(SEP)),
    error: (r.stderr ?? "").trim(),
  };
}

export class TestDb {
  constructor(public readonly name: string) {}

  /** Run SQL as a given actor. The SQL is wrapped so role and JWT claim are set for the session. */
  run(sql: string, actor: Actor = { admin: true }): Result {
    let prefix = "";
    if ("as" in actor) {
      prefix = `set role authenticated; set search_path = public, extensions; set request.jwt.claim.sub = '${actor.as}';\n`;
    } else if ("anon" in actor) {
      prefix = `set role anon; set search_path = public, extensions;\n`;
    }
    return psql(this.name, prefix + sql);
  }

  /** Run SQL and return the first cell, throwing on error. */
  scalar(sql: string, actor: Actor = { admin: true }): string {
    const r = this.run(sql, actor);
    if (!r.ok) throw new Error(`SQL failed: ${r.error}\n${sql}`);
    return r.rows[0]?.[0] ?? "";
  }

  /** Run SQL and throw on error; returns rows. */
  must(sql: string, actor: Actor = { admin: true }): string[][] {
    const r = this.run(sql, actor);
    if (!r.ok) throw new Error(`SQL failed: ${r.error}\n${sql}`);
    return r.rows;
  }

  addUser(label: string): string {
    const id = randomUUID();
    this.must(
      `insert into auth.users (id, email) values ('${id}', '${label}-${id.slice(0, 8)}@example.test');
       insert into profiles (id, full_name, qualifications, registration_no, specialty)
       values ('${id}', '${label}', 'MBBS', 'REG-${id.slice(0, 6)}', 'General Medicine');`,
    );
    return id;
  }

  drop(): void {
    spawnSync("psql", ["-h", HOST, "-p", PORT, "-U", SUPERUSER, "-d", "postgres", "-X", "-q",
      "-c", `drop database if exists "${this.name}" with (force)`]);
  }
}

/** Create a fresh database with the Supabase stub and every migration applied in order. */
export function createTestDb(): TestDb {
  const name = `medico_test_${process.pid}_${Date.now()}`;
  const create = spawnSync("psql", ["-h", HOST, "-p", PORT, "-U", SUPERUSER, "-d", "postgres",
    "-X", "-q", "-v", "ON_ERROR_STOP=1", "-c", `create database "${name}"`], { encoding: "utf8" });
  if (create.status !== 0) {
    throw new Error(
      `Cannot create test database. Is the cluster running? (pnpm db:cluster:start)\n${create.stderr}`,
    );
  }
  const db = new TestDb(name);
  const stub = readFileSync(path.join(here, "supabase_stub.sql"), "utf8");
  const stubResult = psql(name, stub);
  if (!stubResult.ok) throw new Error(`stub failed: ${stubResult.error}`);

  const dir = path.join(repoRoot, "supabase/migrations");
  const files = readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();
  for (const f of files) {
    // The storage migration needs Supabase's `storage` schema, which the local database lacks.
    if (f.includes("storage_policies")) continue;
    const r = psql(name, readFileSync(path.join(dir, f), "utf8"));
    if (!r.ok) throw new Error(`migration ${f} failed: ${r.error}`);
  }
  return db;
}

/** Assert a result failed and that the message matches. */
export function failureOf(r: Result): string {
  if (r.ok) throw new Error("expected the statement to fail, but it succeeded");
  return r.error;
}
