import { describe, test, before, after } from "node:test";
import assert from "node:assert/strict";
import { can, ALL_ACTIONS, ALL_ROLES, type Action } from "../../business-logic/src/permissions.ts";
import type { ClinicRole } from "../../types/src/index.ts";
import { buildWorld, World, newDraft, addMed, affected, countOf } from "./world.ts";

let w: World;
let n = 0;
before(() => { w = buildWorld(); });
after(() => w.db.drop());

const userFor = (role: ClinicRole) => ({ owner: w.alice, doctor: w.doc2, assistant: w.carol, readonly: w.dan })[role];

/** Try to perform `action` as `user` against the real database; true if the database allowed it. */
function attempt(action: Action, user: string): boolean {
  const as = { as: user };
  n++;
  switch (action) {
    case "clinical:read":
      return countOf(w.db, `select 1 from patients where id = '${w.patientA}'`, as) === 1;
    case "patient:write":
      return w.db.run(`insert into patients (clinic_id, full_name, created_by) values ('${w.A}', 'Matrix ${n}', '${user}')`, as).ok;
    case "appointment:write":
      return w.db.run(
        `insert into appointments (clinic_id, patient_id, doctor_id, starts_at, ends_at, created_by)
         values ('${w.A}', '${w.patientA}', '${w.alice}', now() + interval '${10 + n} day', now() + interval '${10 + n} day 30 minutes', '${user}')`, as).ok;
    case "encounter:write":
      return w.db.run(`insert into encounters (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${user}')`, as).ok;
    case "prescription:create":
      return w.db.run(`insert into prescriptions (clinic_id, patient_id, doctor_id) values ('${w.A}', '${w.patientA}', '${user}')`, as).ok;
    case "prescription:amend": {
      const rx = newDraft(w);
      addMed(w, rx, 1, "Matrix medicine");
      w.db.must(`select finalize_prescription('${rx}')`, { as: w.alice });
      return w.db.run(`select amend_prescription('${rx}', 'matrix check')`, as).ok;
    }
    case "medicine:manage":
      return w.db.run(`insert into medicines (clinic_id, generic_name, source) values ('${w.A}', 'Matrix drug ${n}', 'user')`, as).ok;
    case "member:manage": {
      const newcomer = w.db.addUser(`Newcomer ${n}`);
      return w.db.run(`insert into clinic_members (clinic_id, user_id, role) values ('${w.A}', '${newcomer}', 'readonly')`, as).ok;
    }
    case "clinic:update":
      return affected(w.db, `update clinics set phone = '+92 300 ${String(1000000 + n)}' where id = '${w.A}'`, as) === 1;
    case "audit:read":
      return countOf(w.db, `select 1 from audit_events where clinic_id = '${w.A}'`, as) > 0;
  }
}

describe("the UI permission table matches what the database actually enforces", () => {
  for (const role of ALL_ROLES) {
    test(`${role}: every action is allowed or refused by the database exactly as the table says`, () => {
      const user = userFor(role);
      for (const action of ALL_ACTIONS) {
        assert.equal(attempt(action, user), can(role, action), `${role} / ${action}: database and permission table disagree`);
      }
    });
  }
});
