import { createTestDb, TestDb } from "./harness.ts";

/** Two independent clinics with staff in each role, plus an outsider. */
export type World = {
  db: TestDb;
  alice: string; // owner + doctor of clinic A
  doc2: string; // second doctor in clinic A
  carol: string; // assistant in clinic A
  dan: string; // read-only in clinic A
  bob: string; // owner + doctor of clinic B (a different clinic)
  eve: string; // authenticated user with no clinic
  A: string;
  B: string;
  patientA: string;
  patientB: string;
};

export function buildWorld(): World {
  const db = createTestDb();
  const alice = db.addUser("Dr Alice");
  const doc2 = db.addUser("Dr Second");
  const carol = db.addUser("Carol Assistant");
  const dan = db.addUser("Dan Readonly");
  const bob = db.addUser("Dr Bob");
  const eve = db.addUser("Eve Outsider");

  const A = db.scalar(`select create_clinic('Alice Clinic', '12 Mall Road, Lahore', '+92 300 0000001')`, { as: alice });
  const B = db.scalar(`select create_clinic('Bob Clinic', '5 Canal Road, Karachi', '+92 300 0000002')`, { as: bob });

  db.must(
    `insert into clinic_members (clinic_id, user_id, role) values
       ('${A}', '${doc2}', 'doctor'),
       ('${A}', '${carol}', 'assistant'),
       ('${A}', '${dan}', 'readonly');`,
    { as: alice },
  );

  const patientA = db.scalar(
    `insert into patients (clinic_id, full_name, phone, sex, created_by)
     values ('${A}', 'Ayesha Khan', '+92 311 1111111', 'female', '${alice}') returning id`,
    { as: alice },
  );
  const patientB = db.scalar(
    `insert into patients (clinic_id, full_name, phone, sex, created_by)
     values ('${B}', 'Bilal Ahmed', '+92 322 2222222', 'male', '${bob}') returning id`,
    { as: bob },
  );
  return { db, alice, doc2, carol, dan, bob, eve, A, B, patientA, patientB };
}

export const countOf = (db: TestDb, query: string, actor: Parameters<TestDb["run"]>[1]) =>
  Number(db.scalar(`select count(*) from (${query}) q`, actor));

/** Rows affected by an UPDATE/DELETE ... (without RETURNING), counted via a CTE. */
export const affected = (db: TestDb, stmt: string, actor: Parameters<TestDb["run"]>[1]) =>
  Number(db.scalar(`with x as (${stmt} returning 1) select count(*) from x`, actor));

export function newDraft(w: World, opts: { patient?: string; clinic?: string; doctor?: string; diagnosis?: string } = {}) {
  const clinic = opts.clinic ?? w.A;
  const doctor = opts.doctor ?? w.alice;
  return w.db.scalar(
    `insert into prescriptions (clinic_id, patient_id, doctor_id, diagnosis, advice)
     values ('${clinic}', '${opts.patient ?? w.patientA}', '${doctor}', '${opts.diagnosis ?? "Viral fever"}', 'Rest and fluids')
     returning id`,
    { as: doctor },
  );
}

export function addMed(w: World, rx: string, position: number, name: string, doctor = w.alice, clinic = w.A) {
  return w.db.scalar(
    `insert into prescription_medications
       (clinic_id, prescription_id, position, name, strength, dosage_form, dose, route, frequency, duration, quantity)
     values ('${clinic}', '${rx}', ${position}, '${name}', '500 mg', 'Tablet', '1 tablet', 'Oral', 'Twice daily', '5 days', '10')
     returning id`,
    { as: doctor },
  );
}
