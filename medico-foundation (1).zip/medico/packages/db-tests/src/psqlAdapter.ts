import type { Db, Query } from "../../api-core/src/db.ts";
import type { TestDb } from "./harness.ts";

/** Quote a JS value as a SQL literal (psql runs with standard_conforming_strings on). */
function literal(v: unknown): string {
  if (v === null || v === undefined) return "null";
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  const s = String(v);
  if (s.includes("\0")) throw new Error("NUL byte in parameter");
  return `'${s.replace(/'/g, "''")}'`;
}

function bind(sql: string, params: readonly unknown[]): string {
  return sql.replace(/\$(\d+)/g, (_m, n: string) => {
    const i = Number(n) - 1;
    if (i < 0 || i >= params.length) throw new Error(`missing parameter $${n}`);
    return literal(params[i]);
  });
}

/**
 * Test-only adapter: runs the services' SQL through psql against the local throwaway cluster, as
 * role `authenticated` (or `anon`) with the JWT subject set, exactly like a Supabase request.
 * Each query is its own session, which is fine for the read-only flows under test.
 */
export function psqlDb(db: TestDb): Db {
  return {
    async asUser<T>(userId: string | null, fn: (query: Query) => Promise<T>): Promise<T> {
      const actor = userId === null ? ({ anon: true } as const) : ({ as: userId } as const);
      const query: Query = async <R>(sql: string, params: readonly unknown[] = []) => {
        const r = db.run(`select row_to_json(q)::text from (${bind(sql, params)}) q`, actor);
        if (!r.ok) throw new Error(r.error);
        return r.rows.map((cols) => JSON.parse(cols[0] ?? "null") as R);
      };
      return fn(query);
    },
  };
}
