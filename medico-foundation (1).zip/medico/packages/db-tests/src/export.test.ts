import { describe, test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { exportPrescriptionPdf } from "../../api-core/src/prescriptionExport.ts";
import { ForbiddenError, InvalidInputError, NotFoundError, UnauthenticatedError } from "../../api-core/src/errors.ts";
import { readPdf } from "../../pdf/src/testing.ts";
import { psqlDb } from "./psqlAdapter.ts";
import { buildWorld, World, newDraft, addMed, countOf } from "./world.ts";

let w: World;
let api: ReturnType<typeof psqlDb>;
before(() => { w = buildWorld(); api = psqlDb(w.db); });
after(() => w.db.drop());

const exportAs = (user: string | null, rx: string) => exportPrescriptionPdf(api, user, rx);

function finalized(doctor = w.alice) {
  const rx = newDraft(w, { doctor });
  addMed(w, rx, 1, "Paracetamol");
  addMed(w, rx, 2, "Amoxicillin");
  w.db.must(`select finalize_prescription('${rx}')`, { as: doctor });
  return rx;
}
const exports = (rx: string) =>
  countOf(w.db, `select 1 from audit_events where action = 'export_pdf' and entity_id = '${rx}'`, { admin: true });

describe("PDF export of an issued prescription", () => {
  test("a doctor gets a real PDF, rendered from the signed snapshot, with the right patient and medicines", async () => {
    const rx = finalized();
    const out = await exportAs(w.alice, rx);
    assert.equal(out.source, "snapshot");
    assert.equal(out.contentType, "application/pdf");
    assert.match(out.sha256, /^[0-9a-f]{64}$/);
    assert.match(out.filename, /^RX-\d{6}\.pdf$/);
    const p = await readPdf(out.bytes);
    for (const s of ["Ayesha Khan", "Alice Clinic", "12 Mall Road, Lahore", "Dr Alice", "Paracetamol", "Amoxicillin", "Viral fever", out.filename.replace(".pdf", "")])
      assert.ok(p.text.includes(s), `missing "${s}"`);
    assert.ok(!p.text.includes("Bilal Ahmed") && !p.text.includes("Bob Clinic"), "must never contain another clinic's data");
    assert.ok(!p.text.includes("DRAFT") && !p.text.includes("SUPERSEDED"));
  });

  test("every role in the clinic can download an issued prescription", async () => {
    const rx = finalized();
    for (const [who, user] of [["doctor", w.doc2], ["assistant", w.carol], ["read-only", w.dan], ["owner", w.alice]] as const) {
      const out = await exportAs(user, rx);
      assert.ok(out.bytes.length > 1000, `${who} got no PDF`);
    }
  });

  test("each successful export is audited once, with identifiers only", async () => {
    const rx = finalized();
    assert.equal(exports(rx), 0);
    await exportAs(w.carol, rx);
    await exportAs(w.alice, rx);
    assert.equal(exports(rx), 2);
    const row = w.db.must(`select actor_id, clinic_id, changed_columns from audit_events where action = 'export_pdf' and entity_id = '${rx}' order by id limit 1`)[0]!;
    assert.equal(row[0], w.carol);
    assert.equal(row[1], w.A);
    assert.equal(row[2], "", "no column values or patient data in the audit row");
    // Only the owner can read the audit log.
    assert.equal(countOf(w.db, `select 1 from audit_events where action = 'export_pdf'`, { as: w.carol }), 0);
    assert.ok(countOf(w.db, `select 1 from audit_events where action = 'export_pdf'`, { as: w.alice }) >= 2);
  });

  test("the PDF shows what was signed even if the patient or clinic record is edited afterwards", async () => {
    const rx = finalized();
    w.db.must(`update patients set full_name = 'Ayesha Renamed' where id = '${w.patientA}'`, { as: w.alice });
    w.db.must(`update clinics set name = 'Renamed Clinic' where id = '${w.A}'`, { as: w.alice });
    const p = await readPdf((await exportAs(w.alice, rx)).bytes);
    assert.ok(p.text.includes("Ayesha Khan") && p.text.includes("Alice Clinic"));
    assert.ok(!p.text.includes("Ayesha Renamed") && !p.text.includes("Renamed Clinic"));
    // A prescription issued after the rename carries the new details.
    const rx2 = finalized();
    const p2 = await readPdf((await exportAs(w.alice, rx2)).bytes);
    assert.ok(p2.text.includes("Ayesha Renamed") && p2.text.includes("Renamed Clinic"));
    w.db.must(`update patients set full_name = 'Ayesha Khan' where id = '${w.patientA}'`, { as: w.alice });
    w.db.must(`update clinics set name = 'Alice Clinic' where id = '${w.A}'`, { as: w.alice });
  });

  test("a long medication list produces a multi-page PDF through the whole stack", async () => {
    const rx = newDraft(w);
    for (let i = 1; i <= 40; i++) addMed(w, rx, i, `Long list medicine ${i}`);
    w.db.must(`select finalize_prescription('${rx}')`, { as: w.alice });
    const out = await exportAs(w.alice, rx);
    const p = await readPdf(out.bytes);
    assert.ok(out.pageCount >= 3);
    assert.equal(p.pageCount, out.pageCount);
    assert.ok(p.text.includes("Long list medicine 40"));
  });
});

describe("who can NOT download", () => {
  test("another clinic's owner and a user with no clinic get 'not found', same as a missing id", async () => {
    const rx = finalized();
    const before = exports(rx);
    const missing = await exportAs(w.bob, randomUUID()).catch((e) => e);
    assert.ok(missing instanceof NotFoundError);
    for (const user of [w.bob, w.eve]) {
      const err = await exportAs(user, rx).catch((e) => e);
      assert.ok(err instanceof NotFoundError, `expected NotFoundError, got ${err}`);
      assert.equal(err.message, missing.message, "existing-but-forbidden must look identical to missing");
    }
    assert.equal(exports(rx), before, "failed attempts are not logged as exports");
  });

  test("an unauthenticated caller is rejected before any query runs", async () => {
    const rx = finalized();
    await assert.rejects(() => exportAs(null, rx), UnauthenticatedError);
  });

  test("an anonymous database session cannot read prescriptions even if a service forgot to check", () => {
    const rx = finalized();
    const read = w.db.run(`select 1 from prescriptions where id = '${rx}'`, { anon: true });
    assert.equal(read.ok, false);
    assert.match(read.error, /permission denied/);
    const r = w.db.run(`select record_prescription_export('${rx}')`, { anon: true });
    assert.equal(r.ok, false);
    assert.match(r.error, /permission denied/);
  });

  test("malformed ids are rejected and cannot be used for injection", async () => {
    for (const bad of ["abc", "", "' or 1=1 --", "00000000-0000-0000-0000-000000000000'; drop table patients; --"])
      await assert.rejects(() => exportAs(w.alice, bad), InvalidInputError);
    assert.ok(countOf(w.db, `select 1 from patients`, { admin: true }) >= 2, "patients table intact");
  });

  test("a suspended member loses download access immediately", async () => {
    const rx = finalized();
    w.db.must(`update clinic_members set status = 'suspended' where clinic_id = '${w.A}' and user_id = '${w.dan}'`, { as: w.alice });
    await assert.rejects(() => exportAs(w.dan, rx), NotFoundError);
    w.db.must(`update clinic_members set status = 'active' where clinic_id = '${w.A}' and user_id = '${w.dan}'`, { as: w.alice });
    assert.ok((await exportAs(w.dan, rx)).bytes.length > 1000);
  });
});

describe("drafts and amendments", () => {
  test("only prescribers can preview a draft, and it is watermarked", async () => {
    const rx = newDraft(w);
    addMed(w, rx, 1, "Draft medicine");
    const out = await exportAs(w.alice, rx);
    assert.equal(out.source, "draft");
    assert.ok((await readPdf(out.bytes)).text.includes("DRAFT - NOT VALID"));
    await assert.rejects(() => exportAs(w.carol, rx), ForbiddenError); // assistant
    await assert.rejects(() => exportAs(w.dan, rx), ForbiddenError); // read-only
    await assert.rejects(() => exportAs(w.bob, rx), NotFoundError); // other clinic
  });

  test("an amended original is marked superseded and the amendment says what it replaces", async () => {
    const rx = finalized();
    const rxNo = w.db.scalar(`select rx_number from prescriptions where id = '${rx}'`);
    const amend = w.db.scalar(`select amend_prescription('${rx}', 'Wrong dose of amoxicillin')`, { as: w.alice });
    w.db.must(`update prescription_medications set dose = '2 tablets' where prescription_id = '${amend}' and name = 'Amoxicillin'`, { as: w.alice });
    w.db.must(`select finalize_prescription('${amend}')`, { as: w.alice });

    const original = await readPdf((await exportAs(w.alice, rx)).bytes);
    assert.ok(original.text.includes("SUPERSEDED"));
    assert.ok(original.text.includes("1 tablet"), "the original keeps its original content");

    const out = await exportAs(w.alice, amend);
    const fixed = await readPdf(out.bytes);
    assert.equal(out.filename, `${rxNo}-A1.pdf`);
    assert.ok(fixed.text.includes(`Replaces ${rxNo}`));
    assert.ok(fixed.text.includes("Wrong dose of amoxicillin"));
    assert.ok(fixed.text.includes("2 tablets"));
    assert.ok(!fixed.text.includes("SUPERSEDED"));
  });
});
