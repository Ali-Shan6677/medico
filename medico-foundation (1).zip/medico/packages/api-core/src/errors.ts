/** Input was malformed (for example an id that is not a UUID). Maps to HTTP 400. */
export class InvalidInputError extends Error { readonly status = 400; }
/** Not signed in. Maps to HTTP 401. */
export class UnauthenticatedError extends Error { readonly status = 401; }
/**
 * The record does not exist OR the caller may not see it. The two cases are deliberately
 * indistinguishable so a caller cannot probe for other clinics' record ids. Maps to HTTP 404.
 */
export class NotFoundError extends Error { readonly status = 404; }
/** The caller can see the record but the action is not allowed for their role. Maps to HTTP 403. */
export class ForbiddenError extends Error { readonly status = 403; }
