import { createHash } from "node:crypto";
import { generatePrescriptionPdf, type PdfOptions } from "../../pdf/src/index.ts";
import type { PrescriptionDocument, MedicationLine } from "../../types/src/index.ts";
import type { Db, Query } from "./db.ts";
import { ForbiddenError, InvalidInputError, NotFoundError, UnauthenticatedError } from "./errors.ts";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export interface PrescriptionPdfExport {
  bytes: Uint8Array;
  filename: string;
  contentType: "application/pdf";
  sha256: string;
  pageCount: number;
  /** Non-fatal rendering problems to show to the user. */
  warnings: string[];
  /** Issued prescriptions are rendered from their immutable snapshot; drafts from live rows. */
  source: "snapshot" | "draft";
}

type RxRow = {
  id: string; clinic_id: string; status: "draft" | "finalized" | "superseded"; rx_number: string;
  amends_id: string | null; amendment_reason: string | null;
  diagnosis: string | null; advice: string | null; followup_advice: string | null;
  finalized_at: string | null; patient_id: string; doctor_id: string;
};

/**
 * Render a prescription as a PDF for `userId`.
 *
 * Authorization is enforced by the database: every read below runs as the caller, so a user who
 * cannot see the prescription (another clinic's, or one that does not exist) gets NotFoundError.
 * Drafts additionally require a prescriber role. Each successful export is written to the audit log.
 */
export async function exportPrescriptionPdf(
  db: Db,
  userId: string | null,
  prescriptionId: string,
  options: PdfOptions = {},
): Promise<PrescriptionPdfExport> {
  if (userId === null) throw new UnauthenticatedError("sign in to download prescriptions");
  if (!UUID.test(prescriptionId)) throw new InvalidInputError("prescription id must be a UUID");

  const { doc, source } = await db.asUser(userId, async (q) => {
    const rows = await q<RxRow>(
      `select id, clinic_id, status, rx_number, amends_id, amendment_reason, diagnosis, advice,
              followup_advice, finalized_at, patient_id, doctor_id
         from prescriptions where id = $1`, [prescriptionId]);
    const rx = rows[0];
    if (!rx) throw new NotFoundError("prescription not found");

    let built: PrescriptionDocument;
    let src: "snapshot" | "draft";
    if (rx.status === "draft") {
      const [{ ok } = { ok: false }] = await q<{ ok: boolean }>(`select is_prescriber($1) as ok`, [rx.clinic_id]);
      if (!ok) throw new ForbiddenError("only prescribers can preview a draft prescription");
      built = await fromLiveRows(q, rx);
      src = "draft";
    } else {
      built = await fromSnapshot(q, rx);
      src = "snapshot";
    }
    await q(`select record_prescription_export($1)`, [prescriptionId]);
    return { doc: built, source: src };
  });

  const pdf = await generatePrescriptionPdf(doc, options);
  return {
    bytes: pdf.bytes,
    filename: `${doc.rx_number}.pdf`,
    contentType: "application/pdf",
    sha256: createHash("sha256").update(pdf.bytes).digest("hex"),
    pageCount: pdf.pageCount,
    warnings: pdf.warnings,
    source,
  };
}

async function amendedNumber(q: Query, rx: RxRow): Promise<string | null> {
  if (!rx.amends_id) return null;
  const rows = await q<{ rx_number: string }>(`select rx_number from prescriptions where id = $1`, [rx.amends_id]);
  return rows[0]?.rx_number ?? null;
}

/** Issued prescriptions: render exactly what was signed, even if the patient or clinic record changed later. */
async function fromSnapshot(q: Query, rx: RxRow): Promise<PrescriptionDocument> {
  const versions = await q<{ content: Omit<PrescriptionDocument, "status" | "issued_at"> & { finalized_at: string | null } }>(
    `select content from prescription_versions where prescription_id = $1 order by version_no desc limit 1`,
    [rx.id]);
  const content = versions[0]?.content;
  if (!content) throw new Error(`integrity error: ${rx.rx_number} is ${rx.status} but has no stored version`);
  return {
    rx_number: content.rx_number,
    status: rx.status,
    issued_at: content.finalized_at ?? rx.finalized_at,
    diagnosis: content.diagnosis,
    advice: content.advice,
    followup_advice: content.followup_advice,
    amends_rx_number: await amendedNumber(q, rx),
    amendment_reason: rx.amendment_reason,
    patient: content.patient,
    clinic: content.clinic,
    doctor: content.doctor,
    medications: content.medications,
  };
}

/** Drafts have no snapshot yet, so they are rendered from the current rows (and watermarked). */
async function fromLiveRows(q: Query, rx: RxRow): Promise<PrescriptionDocument> {
  const [patient] = await q<PrescriptionDocument["patient"]>(
    `select id, patient_no, full_name, date_of_birth::text as date_of_birth, sex, phone from patients where id = $1`, [rx.patient_id]);
  const [clinic] = await q<PrescriptionDocument["clinic"]>(
    `select id, name, address, phone from clinics where id = $1`, [rx.clinic_id]);
  const [doctor] = await q<PrescriptionDocument["doctor"]>(
    `select id, full_name, qualifications, registration_no, specialty from profiles where id = $1`, [rx.doctor_id]);
  if (!patient || !clinic || !doctor) throw new NotFoundError("prescription details are not available");
  const medications = await q<MedicationLine>(
    `select position, name, strength, dosage_form, dose, route, frequency, duration, quantity, instructions
       from prescription_medications where prescription_id = $1 order by position`, [rx.id]);
  return {
    rx_number: rx.rx_number,
    status: "draft",
    issued_at: null,
    diagnosis: rx.diagnosis,
    advice: rx.advice,
    followup_advice: rx.followup_advice,
    amends_rx_number: await amendedNumber(q, rx),
    amendment_reason: rx.amendment_reason,
    patient, clinic, doctor, medications,
  };
}
