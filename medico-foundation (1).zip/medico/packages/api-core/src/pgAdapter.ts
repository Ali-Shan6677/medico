import type { Db, Query } from "./db.ts";

/** The slice of node-postgres (`pg`) this adapter needs. Typed structurally so no dependency is required here. */
export interface PgClientLike {
  query(text: string, values?: unknown[]): Promise<{ rows: any[] }>;
  release(): void;
}
export interface PgPoolLike {
  connect(): Promise<PgClientLike>;
}

/**
 * Production adapter for a `pg` Pool connected as a LOW-PRIVILEGE login that may `set role
 * authenticated` / `anon` (on Supabase, the pooled `postgres` connection can do this; never use
 * the service-role key for user requests). Each call is one transaction, so `set local` settings
 * cannot leak to the next request on the same pooled connection.
 *
 * NOT EXERCISED IN THIS REPOSITORY'S TESTS: the `pg` package could not be installed in the build
 * environment. The tests run the same services through a psql-based adapter instead.
 */
export function pgDb(pool: PgPoolLike): Db {
  return {
    async asUser<T>(userId: string | null, fn: (query: Query) => Promise<T>): Promise<T> {
      const client = await pool.connect();
      try {
        await client.query("begin");
        if (userId === null) {
          await client.query("set local role anon");
        } else {
          await client.query("set local role authenticated");
          await client.query("select set_config('request.jwt.claim.sub', $1, true)", [userId]);
        }
        const query: Query = async (sql, params = []) => (await client.query(sql, [...params])).rows;
        const result = await fn(query);
        await client.query("commit");
        return result;
      } catch (err) {
        await client.query("rollback").catch(() => undefined);
        throw err;
      } finally {
        client.release();
      }
    },
  };
}
