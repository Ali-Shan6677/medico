/**
 * The only database contract the server-side services rely on.
 *
 * `asUser` runs `fn` so that the database sees `userId` as the signed-in user (Supabase: the JWT
 * `sub` claim, role `authenticated`) and Row Level Security applies to every query inside `fn`.
 * `null` means an unauthenticated caller (role `anon`).
 *
 * Services never use a privileged connection for user requests. That is what keeps authorization
 * in the database rather than in application code that could forget a check.
 */
export type Row = Record<string, unknown>;
export type Query = <R = Row>(sql: string, params?: readonly unknown[]) => Promise<R[]>;

export interface Db {
  asUser<T>(userId: string | null, fn: (query: Query) => Promise<T>): Promise<T>;
}
