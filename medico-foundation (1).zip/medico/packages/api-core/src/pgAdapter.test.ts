import { describe, test } from "node:test";
import assert from "node:assert/strict";
import { pgDb, type PgPoolLike } from "./pgAdapter.ts";

function fakePool(failOn?: string) {
  const log: string[] = [];
  let released = 0;
  const pool: PgPoolLike = {
    async connect() {
      return {
        async query(text: string, values?: unknown[]) {
          log.push(values?.length ? `${text} [${values.join(",")}]` : text);
          if (failOn && text.includes(failOn)) throw new Error("boom");
          return { rows: [{ ok: 1 }] };
        },
        release() { released++; },
      };
    },
  };
  return { pool, log, released: () => released };
}

describe("pg adapter transaction handling (call sequence only; no real pg server is available here)", () => {
  test("one transaction per request, role and user set locally, committed, connection released", async () => {
    const f = fakePool();
    const rows = await pgDb(f.pool).asUser("11111111-1111-1111-1111-111111111111", (q) => q("select 1"));
    assert.deepEqual(rows, [{ ok: 1 }]);
    assert.deepEqual(f.log, [
      "begin",
      "set local role authenticated",
      "select set_config('request.jwt.claim.sub', $1, true) [11111111-1111-1111-1111-111111111111]",
      "select 1",
      "commit",
    ]);
    assert.equal(f.released(), 1);
  });

  test("anonymous callers run as anon with no user claim", async () => {
    const f = fakePool();
    await pgDb(f.pool).asUser(null, (q) => q("select 1"));
    assert.deepEqual(f.log, ["begin", "set local role anon", "select 1", "commit"]);
  });

  test("an error rolls back, never commits, and still releases the connection", async () => {
    const f = fakePool("select 2");
    await assert.rejects(() => pgDb(f.pool).asUser("u", (q) => q("select 2")), /boom/);
    assert.ok(f.log.includes("rollback") && !f.log.includes("commit"));
    assert.equal(f.released(), 1);
  });
});
