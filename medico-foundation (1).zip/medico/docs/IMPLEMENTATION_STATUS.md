# MEDICO implementation status

Last updated: 2026-10-24. Everything marked **Tested** was executed in this repository's environment;
the exact commands and results are at the bottom. Nothing here is marked done unless it was run.

## Implemented and tested

| Area | What exists | Evidence |
|---|---|---|
| Database schema | Clinics, memberships, patients, allergies, encounters, medicines, favorites, appointments (no-overlap constraint), follow-ups, prescriptions, prescription medications, immutable prescription versions, audit events, per-clinic counters (migrations 1-3, 5) | `packages/db-tests` (66 tests across security, integrity and prescription rules) |
| Authorization (Row Level Security) | Clinic membership checks, four roles (owner, doctor, assistant, read-only), suspended members lose access, cross-clinic reads/writes denied, anon role denied, server-managed tables not writable by clients | `security.test.ts`, `integrity.test.ts` |
| Prescription rules | Auto numbering per clinic, draft edit/reorder/delete, finalize requires a medication, finalized prescriptions and their medications cannot be changed or deleted, versions are append-only, corrections are amendments that supersede the original | `prescriptions.test.ts` |
| Prescription PDF | Real A4 PDF: branding, clinic, doctor, patient, reference, date, diagnosis, medications, advice, follow-up, signature area; multi-page with repeated reference and page numbers; draft/superseded watermarks; amendment banner; missing optional fields; text wrapping; unsupported characters replaced and reported | `packages/pdf` (10 tests, PDFs re-opened and read with pdf.js) |
| Authorized PDF export | Service renders issued prescriptions from the signed snapshot (later patient/clinic edits do not change it), drafts only for prescribers, every export audited with identifiers only; other-clinic and missing ids are indistinguishable (not found); bad ids rejected; suspended members blocked immediately | `export.test.ts` (12 tests) |
| Role matrix cross-check | The UI permission table is run action by action against the real database for all four roles and matches it exactly; a deliberate mismatch makes the test fail | `rolematrix.test.ts` (4 tests) |
| Type check | `tsc --noEmit` passes | see below |

## Implemented but NOT verified

- `supabase/migrations/20261024000004_storage_policies.sql` (private PDF bucket policies): needs Supabase's `storage` schema, which the local test database does not have.
- `packages/api-core/src/pgAdapter.ts` (production database adapter for `pg`): only its transaction call sequence is tested with a fake pool (3 tests). It has not run against a real `pg` connection because the package could not be installed.

## Not implemented

- Web dashboard (Next.js) and mobile app (Expo): no UI exists yet.
- Authentication screens and flows (registration, login, password reset, sessions). The database trusts Supabase Auth's user id; nothing creates users yet.
- Patient, consultation and prescription-builder screens and the API layer they need (the database rules exist and are tested).
- Medicine search/autocomplete endpoints, CSV import and sample catalogue.
- Appointment calendar and follow-up reminders (tables and no-overlap rule exist; no UI or notifications).
- Reports and analytics, CSV export.
- AI assistant, voice notes, history summaries.
- Offline storage and synchronization.
- English/Urdu interface and right-to-left layout. Urdu text in PDFs is replaced by `?` and a warning is returned until a Unicode font is embedded.
- Doctor signature and clinic logo storage (`profiles` has no signature column yet; the PDF accepts signature image bytes).
- Uploading generated PDFs to private storage and short-lived download links.
- Staff invitations, account deactivation and data export workflows.
- Backups, monitoring, deployment configuration, Android/iOS builds.

## Blocked by the environment

- The npm registry is unreachable here, so `zod`, `pg`, `next`, `expo`, `vitest` and `@types/*` could not be installed. Validation helpers are hand-written (`packages/types`); tests use `node:test` via `tsx`.
- No GitHub write access: the push from this session is refused, so the code is delivered as files.
- No Supabase project, Docker or AI provider keys.

## Known limitations

- Database tests run on a local PostgreSQL 16 with a small stand-in for Supabase's `auth` schema (`packages/db-tests/src/supabase_stub.sql`). They have not been run on Supabase itself.
- The psql-based test adapter runs each query in its own session; the production adapter uses one transaction per request.

## Commands and results (2026-10-24)

```
bash scripts/pg-test-cluster.sh start     # local PostgreSQL 16 for the database tests
tsx --test "packages/**/*.test.ts"        # 104 tests, 24 suites: 104 pass, 0 fail
tsc --noEmit -p tsconfig.json             # exit code 0
```
