# Security model (current scope)

Design rule: **authorization lives in the database.** Services run user requests as the Postgres role
`authenticated` with the caller's id set from the verified JWT, so Row Level Security applies to every
query. A service that forgets a check still cannot read another clinic's data.

| Threat | Control | Tested |
|---|---|---|
| Reading another clinic's patients/prescriptions by guessing ids | RLS on every table keyed by `clinic_id`; composite foreign keys keep child rows in the same clinic | yes |
| Probing which ids exist | Forbidden and missing records both return "not found" with the same message | yes |
| Role escalation inside a clinic | Roles checked in policies and triggers; only owners manage members; last owner protected | yes |
| Editing an issued prescription | Triggers block updates/deletes of finalized prescriptions and their medications; versions are append-only; corrections create linked amendments | yes |
| Tampering with the audit log | Clients have no insert/update/delete rights; only triggers and `record_prescription_export` write it; only owners can read it; rows hold identifiers, not patient data | yes |
| Anonymous access | `anon` has no table privileges | yes |
| Injection via ids | Ids validated as UUIDs; queries are parameterized | yes (malformed ids) |
| Access after suspension | Membership status checked on every query | yes |
| PDF file access | Not yet stored; once stored it must use a private bucket with signed, short-lived links (policy file written, unverified) | no |
| AI data exposure, offline data, sync conflicts | Not implemented yet; must be designed before those features ship | n/a |

No claim of legal or regulatory compliance is made.
