#!/usr/bin/env bash
# Starts/stops a throwaway local PostgreSQL cluster used by the database tests.
# Needs PostgreSQL server binaries (initdb, pg_ctl). Override locations with env vars.
set -euo pipefail

PG_BIN="${PG_BIN:-$(ls -d /usr/lib/postgresql/*/bin 2>/dev/null | sort -V | tail -1)}"
PG_DIR="${MEDICO_PG_DIR:-/tmp/medico-pg}"
PG_SOCK="${MEDICO_PG_SOCK:-/tmp/medico-pg-sock}"
PG_PORT="${MEDICO_PG_PORT:-54329}"

# PostgreSQL refuses to run as root; drop to an unprivileged user when needed.
run() {
  if [ "$(id -u)" = "0" ]; then
    runuser -u "${MEDICO_PG_USER:-claude}" -- "$@"
  else
    "$@"
  fi
}

case "${1:-}" in
  start)
    mkdir -p "$PG_SOCK"; chown "${MEDICO_PG_USER:-claude}" "$PG_SOCK" 2>/dev/null || true
    if [ ! -d "$PG_DIR" ]; then
      mkdir -p "$PG_DIR"; chown "${MEDICO_PG_USER:-claude}" "$PG_DIR" 2>/dev/null || true
      run "$PG_BIN/initdb" -D "$PG_DIR" -A trust -E UTF8 --no-locale >/dev/null
    fi
    if ! run "$PG_BIN/pg_ctl" -D "$PG_DIR" status >/dev/null 2>&1; then
      run "$PG_BIN/pg_ctl" -D "$PG_DIR" -l "$PG_DIR/server.log" -w \
        -o "-c listen_addresses='' -c unix_socket_directories=$PG_SOCK -c port=$PG_PORT -c fsync=off" start >/dev/null
    fi
    echo "PostgreSQL ready: host=$PG_SOCK port=$PG_PORT"
    ;;
  stop)
    run "$PG_BIN/pg_ctl" -D "$PG_DIR" -m fast stop >/dev/null 2>&1 || true
    echo "stopped"
    ;;
  *)
    echo "usage: $0 start|stop" >&2; exit 2 ;;
esac
