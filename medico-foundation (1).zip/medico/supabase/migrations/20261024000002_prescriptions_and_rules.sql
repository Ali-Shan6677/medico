-- Prescriptions, versioning, immutability rules, audit trail and clinic helpers.

-- ---------------------------------------------------------------- membership helpers
create or replace function current_role_in(p_clinic uuid) returns clinic_role
language sql stable security definer set search_path = public as $$
  select role from clinic_members
  where clinic_id = p_clinic and user_id = auth.uid() and status = 'active'
$$;

create or replace function is_member(p_clinic uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select current_role_in(p_clinic) is not null
$$;

create or replace function can_write_clinical(p_clinic uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(current_role_in(p_clinic) in ('owner', 'doctor', 'assistant'), false)
$$;

create or replace function is_prescriber(p_clinic uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(current_role_in(p_clinic) in ('owner', 'doctor'), false)
$$;

create or replace function shares_clinic_with(p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from clinic_members me
    join clinic_members other on other.clinic_id = me.clinic_id
    where me.user_id = auth.uid() and me.status = 'active'
      and other.user_id = p_user and other.status = 'active'
  )
$$;

-- Creating a clinic also makes the caller its owner, atomically.
create or replace function create_clinic(p_name text, p_address text default null, p_phone text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null then
    raise exception 'authentication required' using errcode = '28000';
  end if;
  insert into clinics (name, address, phone, created_by)
  values (p_name, p_address, p_phone, auth.uid())
  returning id into v_id;
  insert into clinic_members (clinic_id, user_id, role) values (v_id, auth.uid(), 'owner');
  return v_id;
end $$;

-- A clinic must always keep at least one active owner.
create or replace function clinic_members_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_demotes boolean;
begin
  if old.role = 'owner' and old.status = 'active' then
    v_demotes := tg_op = 'DELETE' or new.role <> 'owner' or new.status <> 'active';
    if v_demotes
       and exists (select 1 from clinics where id = old.clinic_id)
       and not exists (
         select 1 from clinic_members
         where clinic_id = old.clinic_id and role = 'owner' and status = 'active'
           and user_id <> old.user_id)
    then
      raise exception 'a clinic must keep at least one active owner';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger clinic_members_guard_trg before update or delete on clinic_members
  for each row execute function clinic_members_guard();

-- ---------------------------------------------------------------- encounters rules
create or replace function encounters_guard() returns trigger
language plpgsql as $$
begin
  if tg_op = 'DELETE' then
    if old.status <> 'draft' then
      raise exception 'finalized encounters cannot be deleted';
    end if;
    return old;
  end if;
  if old.status = 'finalized' then
    raise exception 'finalized encounters are immutable';
  end if;
  if new.status = 'finalized' then
    new.finalized_at := now();
  end if;
  return new;
end $$;
create trigger encounters_guard_trg before update or delete on encounters
  for each row execute function encounters_guard();

-- ---------------------------------------------------------------- prescriptions
create table prescriptions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  patient_id uuid not null,
  encounter_id uuid,
  doctor_id uuid not null references auth.users(id),
  rx_number text not null default '',
  status prescription_status not null default 'draft',
  amends_id uuid,
  amendment_reason text,
  diagnosis text,
  advice text,
  followup_advice text,
  finalized_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (clinic_id, id),
  unique (clinic_id, rx_number),
  foreign key (clinic_id, patient_id) references patients (clinic_id, id),
  foreign key (clinic_id, encounter_id) references encounters (clinic_id, id),
  foreign key (clinic_id, amends_id) references prescriptions (clinic_id, id),
  check ((status = 'draft') = (finalized_at is null)),
  check ((amends_id is null) = (amendment_reason is null))
);
create index prescriptions_patient_idx on prescriptions (patient_id, created_at desc);
create index prescriptions_clinic_idx on prescriptions (clinic_id, created_at desc);
-- At most one open amendment draft per original prescription.
create unique index prescriptions_one_open_amendment on prescriptions (amends_id)
  where status = 'draft' and amends_id is not null;

create table prescription_medications (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  prescription_id uuid not null,
  position int not null check (position >= 1),
  medicine_id uuid references medicines(id),
  name text not null check (length(trim(name)) > 0),
  strength text,
  dosage_form text,
  dose text,
  route text,
  frequency text,
  duration text,
  quantity text,
  instructions text,
  foreign key (clinic_id, prescription_id) references prescriptions (clinic_id, id) on delete cascade,
  -- Deferred so rows can be reordered inside one transaction.
  constraint prescription_medications_position_uq unique (prescription_id, position)
    deferrable initially deferred
);

create table prescription_versions (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  prescription_id uuid not null,
  version_no int not null check (version_no >= 1),
  content jsonb not null,
  reason text,
  created_by uuid,
  created_at timestamptz not null default now(),
  unique (prescription_id, version_no),
  foreign key (clinic_id, prescription_id) references prescriptions (clinic_id, id)
);

create trigger prescriptions_updated before update on prescriptions
  for each row execute function set_updated_at();

create or replace function prescriptions_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  if new.rx_number is null or new.rx_number = '' then
    if new.amends_id is not null then
      select count(*) + 1 into v_n from prescriptions where amends_id = new.amends_id;
      select rx_number || '-A' || v_n into new.rx_number from prescriptions where id = new.amends_id;
    else
      new.rx_number := 'RX-' || lpad(next_counter(new.clinic_id, 'prescription')::text, 6, '0');
    end if;
  end if;
  return new;
end $$;
create trigger prescriptions_before_insert_trg before insert on prescriptions
  for each row execute function prescriptions_before_insert();

create or replace function prescriptions_guard() returns trigger
language plpgsql as $$
begin
  if tg_op = 'DELETE' then
    if old.status <> 'draft' then
      raise exception 'finalized prescriptions cannot be deleted';
    end if;
    return old;
  end if;

  if new.id <> old.id or new.clinic_id <> old.clinic_id or new.patient_id <> old.patient_id
     or new.doctor_id <> old.doctor_id or new.rx_number <> old.rx_number
     or new.amends_id is distinct from old.amends_id
     or new.amendment_reason is distinct from old.amendment_reason
     or new.created_at <> old.created_at then
    raise exception 'identity fields of a prescription cannot be changed';
  end if;

  if old.status = 'draft' then
    if new.status = 'superseded' then
      raise exception 'a draft cannot be superseded';
    elsif new.status = 'finalized' then
      if not exists (select 1 from prescription_medications where prescription_id = old.id) then
        raise exception 'a prescription needs at least one medication before it can be finalized';
      end if;
      new.finalized_at := now();
    else
      new.finalized_at := null;
    end if;
    return new;
  end if;

  if old.status = 'finalized' and new.status = 'superseded'
     and pg_trigger_depth() > 1
     and (to_jsonb(new) - 'status' - 'updated_at') = (to_jsonb(old) - 'status' - 'updated_at') then
    return new; -- only reachable through finalizing an amendment (nested trigger)
  end if;

  raise exception 'finalized prescriptions are immutable; create an amendment instead';
end $$;
create trigger prescriptions_guard_trg before update or delete on prescriptions
  for each row execute function prescriptions_guard();

create or replace function prescription_medications_guard() returns trigger
language plpgsql as $$
declare v_status prescription_status; v_pid uuid;
begin
  if tg_op = 'UPDATE' and new.prescription_id <> old.prescription_id then
    raise exception 'a medication cannot move between prescriptions';
  end if;
  v_pid := case when tg_op = 'DELETE' then old.prescription_id else new.prescription_id end;
  select status into v_status from prescriptions where id = v_pid;
  if v_status is null then
    if tg_op = 'DELETE' then return old; end if; -- parent already deleted (cascade)
    raise exception 'prescription not found';
  end if;
  if v_status <> 'draft' then
    raise exception 'medications of a finalized prescription cannot be changed';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger prescription_medications_guard_trg
  before insert or update or delete on prescription_medications
  for each row execute function prescription_medications_guard();

create or replace function prescription_versions_guard() returns trigger
language plpgsql as $$
begin
  raise exception 'prescription versions are append-only';
end $$;
create trigger prescription_versions_guard_trg before update or delete on prescription_versions
  for each row execute function prescription_versions_guard();

-- On finalization: write an immutable snapshot, and supersede the original if this is an amendment.
create or replace function prescriptions_after_finalize() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_content jsonb; v_no int;
begin
  if old.status = 'draft' and new.status = 'finalized' then
    select jsonb_build_object(
      'rx_number', new.rx_number,
      'finalized_at', new.finalized_at,
      'diagnosis', new.diagnosis,
      'advice', new.advice,
      'followup_advice', new.followup_advice,
      'amends_id', new.amends_id,
      'amendment_reason', new.amendment_reason,
      'patient', (select jsonb_build_object('id', p.id, 'patient_no', p.patient_no,
                    'full_name', p.full_name, 'date_of_birth', p.date_of_birth, 'sex', p.sex)
                  from patients p where p.id = new.patient_id),
      'clinic', (select jsonb_build_object('id', c.id, 'name', c.name, 'address', c.address, 'phone', c.phone)
                 from clinics c where c.id = new.clinic_id),
      'doctor', (select jsonb_build_object('id', d.id, 'full_name', d.full_name,
                   'qualifications', d.qualifications, 'registration_no', d.registration_no,
                   'specialty', d.specialty)
                 from profiles d where d.id = new.doctor_id),
      'medications', coalesce((
        select jsonb_agg(jsonb_build_object(
                 'position', m.position, 'name', m.name, 'strength', m.strength,
                 'dosage_form', m.dosage_form, 'dose', m.dose, 'route', m.route,
                 'frequency', m.frequency, 'duration', m.duration, 'quantity', m.quantity,
                 'instructions', m.instructions) order by m.position)
        from prescription_medications m where m.prescription_id = new.id), '[]'::jsonb)
    ) into v_content;

    select coalesce(max(version_no), 0) + 1 into v_no
      from prescription_versions where prescription_id = new.id;
    insert into prescription_versions (clinic_id, prescription_id, version_no, content, reason, created_by)
    values (new.clinic_id, new.id, v_no, v_content, new.amendment_reason, auth.uid());

    if new.amends_id is not null then
      update prescriptions set status = 'superseded'
      where id = new.amends_id and clinic_id = new.clinic_id and status = 'finalized';
    end if;
  end if;
  return null;
end $$;
create trigger prescriptions_after_finalize_trg after update on prescriptions
  for each row execute function prescriptions_after_finalize();

create or replace function finalize_prescription(p_id uuid) returns void
language plpgsql as $$
begin
  update prescriptions set status = 'finalized' where id = p_id and status = 'draft';
  if not found then
    raise exception 'prescription not found, not a draft, or not permitted';
  end if;
end $$;

-- Corrections never edit a finalized prescription: they open a new linked draft.
create or replace function amend_prescription(p_id uuid, p_reason text) returns uuid
language plpgsql security definer set search_path = public as $$
declare o prescriptions%rowtype; v_new uuid;
begin
  if auth.uid() is null then
    raise exception 'authentication required' using errcode = '28000';
  end if;
  if p_reason is null or length(trim(p_reason)) = 0 then
    raise exception 'an amendment reason is required';
  end if;
  select * into o from prescriptions where id = p_id;
  if not found or not is_prescriber(o.clinic_id) then
    raise exception 'prescription not found or not permitted';
  end if;
  if o.status <> 'finalized' then
    raise exception 'only a finalized prescription can be amended';
  end if;

  insert into prescriptions (clinic_id, patient_id, encounter_id, doctor_id, amends_id,
                             amendment_reason, diagnosis, advice, followup_advice)
  values (o.clinic_id, o.patient_id, o.encounter_id, auth.uid(), o.id,
          trim(p_reason), o.diagnosis, o.advice, o.followup_advice)
  returning id into v_new;

  insert into prescription_medications (clinic_id, prescription_id, position, medicine_id, name,
      strength, dosage_form, dose, route, frequency, duration, quantity, instructions)
  select clinic_id, v_new, position, medicine_id, name, strength, dosage_form, dose, route,
         frequency, duration, quantity, instructions
  from prescription_medications where prescription_id = o.id;
  return v_new;
end $$;

-- ---------------------------------------------------------------- audit trail
-- Records who did what to which record. It stores column NAMES only, never values,
-- so the audit log does not become a second copy of sensitive data.
create or replace function audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare r jsonb; o jsonb; cols text[];
begin
  r := to_jsonb(case when tg_op = 'DELETE' then old else new end);
  if tg_op = 'UPDATE' then
    o := to_jsonb(old);
    select array_agg(k order by k) into cols
      from jsonb_object_keys(r) k
      where k <> 'updated_at' and (r -> k) is distinct from (o -> k);
    if cols is null then return null; end if;
  end if;
  insert into audit_events (clinic_id, actor_id, action, entity, entity_id, changed_columns)
  values ((r ->> 'clinic_id')::uuid, auth.uid(), lower(tg_op), tg_table_name,
          (r ->> 'id')::uuid, cols);
  return null;
end $$;

create trigger audit_patients after insert or update or delete on patients
  for each row execute function audit_row();
create trigger audit_encounters after insert or update or delete on encounters
  for each row execute function audit_row();
create trigger audit_prescriptions after insert or update or delete on prescriptions
  for each row execute function audit_row();
create trigger audit_appointments after insert or update or delete on appointments
  for each row execute function audit_row();
create trigger audit_clinic_members after insert or update or delete on clinic_members
  for each row execute function audit_row();
