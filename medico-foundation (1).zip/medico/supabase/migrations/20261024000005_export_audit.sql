-- Records that a signed-in clinic member exported a prescription document.
-- The audit log is server-managed (clients cannot insert into it), so exports are logged through
-- this function, which checks membership itself and stores identifiers only, never patient data.
create or replace function record_prescription_export(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare v_clinic uuid;
begin
  if auth.uid() is null then
    raise exception 'authentication required' using errcode = '28000';
  end if;
  select clinic_id into v_clinic from prescriptions where id = p_id;
  if v_clinic is null or not is_member(v_clinic) then
    raise exception 'prescription not found or not permitted';
  end if;
  insert into audit_events (clinic_id, actor_id, action, entity, entity_id, changed_columns)
  values (v_clinic, auth.uid(), 'export_pdf', 'prescriptions', p_id, null);
end $$;

revoke all on function record_prescription_export(uuid) from public, anon;
grant execute on function record_prescription_export(uuid) to authenticated;
