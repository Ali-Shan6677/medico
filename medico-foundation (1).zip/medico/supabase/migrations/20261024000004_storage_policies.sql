-- Private storage for prescription PDFs and clinic documents.
-- Object path convention: <clinic_id>/<prescription_id>/<file>.pdf
-- NOTE: requires the Supabase `storage` schema. These policies are NOT covered by the local
-- automated tests (the test database has no storage schema); verify on a real Supabase project.

insert into storage.buckets (id, name, public)
values ('clinical-documents', 'clinical-documents', false)
on conflict (id) do update set public = false;

create policy clinical_documents_read on storage.objects for select to authenticated
  using (bucket_id = 'clinical-documents'
         and is_member(((storage.foldername(name))[1])::uuid));

create policy clinical_documents_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'clinical-documents'
              and can_write_clinical(((storage.foldername(name))[1])::uuid));
-- No update/delete policies: documents are append-only from clients.
