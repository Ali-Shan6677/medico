-- MEDICO core schema.
-- Assumes a Supabase-style environment: schema `auth` with `auth.users` and `auth.uid()`,
-- and roles `anon`, `authenticated`, `service_role`.

-- Extensions live in their own schema (Supabase convention) so that privilege clean-up on the
-- `public` schema never strips access to their functions.
create schema if not exists extensions;
create extension if not exists pg_trgm with schema extensions;
create extension if not exists btree_gist with schema extensions;

-- ---------------------------------------------------------------- types
create type clinic_role as enum ('owner', 'doctor', 'assistant', 'readonly');
create type member_status as enum ('active', 'suspended');
create type record_status as enum ('draft', 'finalized');
create type prescription_status as enum ('draft', 'finalized', 'superseded');
create type appointment_status as enum ('scheduled', 'completed', 'cancelled', 'no_show');
create type followup_status as enum ('pending', 'done', 'cancelled');
create type medicine_source as enum ('sample', 'licensed_import', 'user');

-- ---------------------------------------------------------------- helpers
create or replace function set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------- profiles
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null check (length(trim(full_name)) > 0),
  qualifications text,
  registration_no text,
  specialty text,
  phone text,
  language text not null default 'en' check (language in ('en', 'ur')),
  timezone text not null default 'Asia/Karachi',
  signature_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on profiles
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------- clinics
create table clinics (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) > 0),
  address text,
  phone text,
  logo_path text,
  timezone text not null default 'Asia/Karachi',
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger clinics_updated before update on clinics
  for each row execute function set_updated_at();

create table clinic_members (
  clinic_id uuid not null references clinics(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role clinic_role not null,
  status member_status not null default 'active',
  created_at timestamptz not null default now(),
  primary key (clinic_id, user_id)
);
create index clinic_members_user_idx on clinic_members (user_id) where status = 'active';

-- Per-clinic counters for human-readable numbers (patient numbers, prescription numbers).
create table clinic_counters (
  clinic_id uuid not null references clinics(id) on delete cascade,
  kind text not null,
  value bigint not null default 0,
  primary key (clinic_id, kind)
);

create or replace function next_counter(p_clinic uuid, p_kind text) returns bigint
language sql security definer set search_path = public as $$
  insert into clinic_counters (clinic_id, kind, value) values (p_clinic, p_kind, 1)
  on conflict (clinic_id, kind) do update set value = clinic_counters.value + 1
  returning value;
$$;
revoke all on function next_counter(uuid, text) from public;

-- ---------------------------------------------------------------- patients
create table patients (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references clinics(id) on delete cascade,
  patient_no text not null,
  full_name text not null check (length(trim(full_name)) > 0),
  date_of_birth date check (date_of_birth <= current_date),
  sex text check (sex in ('female', 'male', 'other')),
  phone text,
  address text,
  emergency_contact text,
  notes text,
  archived_at timestamptz,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (clinic_id, id),
  unique (clinic_id, patient_no)
);
create index patients_name_trgm on patients using gin (lower(full_name) extensions.gin_trgm_ops);
create index patients_phone_idx on patients (clinic_id, phone);
create trigger patients_updated before update on patients
  for each row execute function set_updated_at();

create or replace function patients_assign_no() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.patient_no is null or new.patient_no = '' then
    new.patient_no := 'P-' || lpad(next_counter(new.clinic_id, 'patient')::text, 6, '0');
  end if;
  return new;
end $$;
-- patient_no is NOT NULL, so the trigger must run before the constraint check: default to empty.
alter table patients alter column patient_no set default '';
create trigger patients_assign_no_trg before insert on patients
  for each row execute function patients_assign_no();

create table patient_allergies (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  patient_id uuid not null,
  substance text not null check (length(trim(substance)) > 0),
  reaction text,
  created_at timestamptz not null default now(),
  foreign key (clinic_id, patient_id) references patients (clinic_id, id) on delete cascade
);
create index patient_allergies_patient_idx on patient_allergies (patient_id);

-- ---------------------------------------------------------------- encounters
create table encounters (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  patient_id uuid not null,
  doctor_id uuid not null references auth.users(id),
  visit_at timestamptz not null default now(),
  presenting_complaint text,
  history text,
  examination text,
  diagnosis text,
  plan text,
  advice text,
  followup_instructions text,
  status record_status not null default 'draft',
  finalized_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (clinic_id, id),
  foreign key (clinic_id, patient_id) references patients (clinic_id, id)
);
create index encounters_patient_idx on encounters (patient_id, visit_at desc);
create trigger encounters_updated before update on encounters
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------- medicines
create table medicines (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid references clinics(id) on delete cascade, -- null = shared catalogue
  generic_name text not null check (length(trim(generic_name)) > 0),
  brand_name text,
  strength text,
  dosage_form text,
  category text,
  source medicine_source not null,
  verified boolean not null default false,
  data_source_note text,
  updated_at timestamptz not null default now(),
  check (clinic_id is not null or source <> 'user'),
  check (source <> 'user' or verified = false)
);
create index medicines_search_trgm on medicines
  using gin ((lower(generic_name || ' ' || coalesce(brand_name, ''))) extensions.gin_trgm_ops);
create unique index medicines_unique_entry on medicines
  (coalesce(clinic_id, '00000000-0000-0000-0000-000000000000'::uuid),
   lower(generic_name), lower(coalesce(brand_name, '')), lower(coalesce(strength, '')), lower(coalesce(dosage_form, '')));

create table medicine_favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  medicine_id uuid not null references medicines(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, medicine_id)
);

-- ---------------------------------------------------------------- appointments & follow-ups
create table appointments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  patient_id uuid not null,
  doctor_id uuid not null references auth.users(id),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status appointment_status not null default 'scheduled',
  encounter_id uuid,
  notes text,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at > starts_at),
  foreign key (clinic_id, patient_id) references patients (clinic_id, id),
  foreign key (clinic_id, encounter_id) references encounters (clinic_id, id),
  -- A doctor cannot have two overlapping, non-cancelled appointments.
  exclude using gist (doctor_id with =, tstzrange(starts_at, ends_at) with &&)
    where (status in ('scheduled', 'completed'))
);
create index appointments_clinic_time_idx on appointments (clinic_id, starts_at);
create trigger appointments_updated before update on appointments
  for each row execute function set_updated_at();

create table followups (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null,
  patient_id uuid not null,
  due_at timestamptz not null,
  note text,
  status followup_status not null default 'pending',
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  foreign key (clinic_id, patient_id) references patients (clinic_id, id)
);
create index followups_due_idx on followups (clinic_id, due_at) where status = 'pending';

-- ---------------------------------------------------------------- audit
create table audit_events (
  id bigint generated always as identity primary key,
  clinic_id uuid,
  actor_id uuid,
  action text not null,
  entity text not null,
  entity_id uuid,
  changed_columns text[],
  at timestamptz not null default now()
);
create index audit_events_clinic_idx on audit_events (clinic_id, at desc);
