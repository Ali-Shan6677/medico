-- Row Level Security and privileges.
-- Rule of thumb: every table has RLS enabled; access is decided by clinic membership and role
-- inside the database, never by the UI.

-- ---------------------------------------------------------------- privileges
revoke all on all tables in schema public from anon, authenticated;
-- Supabase grants EXECUTE on new functions to anon/authenticated by default. Remove that for
-- every function (including internal ones such as next_counter), then grant an explicit list below.
revoke all on all functions in schema public from public, anon, authenticated;
-- Future functions created by later migrations start with no client access.
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;

grant usage on schema public to authenticated;

grant select, insert, update on profiles to authenticated;
grant select, update on clinics to authenticated;
grant select, insert, update, delete on clinic_members to authenticated;
grant select, insert, update on patients to authenticated;
grant select, insert, update, delete on patient_allergies to authenticated;
grant select, insert, update, delete on encounters to authenticated;
grant select, insert, update, delete on medicines to authenticated;
grant select, insert, delete on medicine_favorites to authenticated;
grant select, insert, update on appointments to authenticated;
grant select, insert, update on followups to authenticated;
grant select, insert, update, delete on prescriptions to authenticated;
grant select, insert, update, delete on prescription_medications to authenticated;
-- Append-only / server-managed tables: read-only for clients.
grant select on prescription_versions to authenticated;
grant select on audit_events to authenticated;

grant execute on function create_clinic(text, text, text) to authenticated;
grant execute on function finalize_prescription(uuid) to authenticated;
grant execute on function amend_prescription(uuid, text) to authenticated;
grant execute on function current_role_in(uuid) to authenticated;
grant execute on function is_member(uuid) to authenticated;
grant execute on function can_write_clinical(uuid) to authenticated;
grant execute on function is_prescriber(uuid) to authenticated;
grant execute on function shares_clinic_with(uuid) to authenticated;

-- ---------------------------------------------------------------- enable RLS
alter table profiles enable row level security;
alter table clinics enable row level security;
alter table clinic_members enable row level security;
alter table clinic_counters enable row level security; -- no policies: definer functions only
alter table patients enable row level security;
alter table patient_allergies enable row level security;
alter table encounters enable row level security;
alter table medicines enable row level security;
alter table medicine_favorites enable row level security;
alter table appointments enable row level security;
alter table followups enable row level security;
alter table prescriptions enable row level security;
alter table prescription_medications enable row level security;
alter table prescription_versions enable row level security;
alter table audit_events enable row level security;

-- ---------------------------------------------------------------- profiles
create policy profiles_select on profiles for select to authenticated
  using (id = auth.uid() or shares_clinic_with(id));
create policy profiles_insert on profiles for insert to authenticated
  with check (id = auth.uid());
create policy profiles_update on profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- ---------------------------------------------------------------- clinics & members
create policy clinics_select on clinics for select to authenticated
  using (is_member(id));
create policy clinics_update on clinics for update to authenticated
  using (current_role_in(id) = 'owner') with check (current_role_in(id) = 'owner');

create policy members_select on clinic_members for select to authenticated
  using (is_member(clinic_id));
create policy members_insert on clinic_members for insert to authenticated
  with check (current_role_in(clinic_id) = 'owner');
create policy members_update on clinic_members for update to authenticated
  using (current_role_in(clinic_id) = 'owner') with check (current_role_in(clinic_id) = 'owner');
create policy members_delete on clinic_members for delete to authenticated
  using (current_role_in(clinic_id) = 'owner');

-- ---------------------------------------------------------------- patients
create policy patients_select on patients for select to authenticated
  using (is_member(clinic_id));
create policy patients_insert on patients for insert to authenticated
  with check (can_write_clinical(clinic_id) and created_by = auth.uid());
create policy patients_update on patients for update to authenticated
  using (can_write_clinical(clinic_id)) with check (can_write_clinical(clinic_id));
-- No delete policy: patients are archived (archived_at), never deleted by clients.

create policy allergies_select on patient_allergies for select to authenticated
  using (is_member(clinic_id));
create policy allergies_write on patient_allergies for all to authenticated
  using (can_write_clinical(clinic_id)) with check (can_write_clinical(clinic_id));

-- ---------------------------------------------------------------- encounters
create policy encounters_select on encounters for select to authenticated
  using (is_member(clinic_id));
create policy encounters_insert on encounters for insert to authenticated
  with check (is_prescriber(clinic_id) and doctor_id = auth.uid() and status = 'draft');
create policy encounters_update on encounters for update to authenticated
  using (is_prescriber(clinic_id) and doctor_id = auth.uid() and status = 'draft')
  with check (is_prescriber(clinic_id) and doctor_id = auth.uid());
create policy encounters_delete on encounters for delete to authenticated
  using (is_prescriber(clinic_id) and doctor_id = auth.uid() and status = 'draft');

-- ---------------------------------------------------------------- medicines
create policy medicines_select on medicines for select to authenticated
  using (clinic_id is null or is_member(clinic_id));
create policy medicines_insert on medicines for insert to authenticated
  with check (clinic_id is not null and is_prescriber(clinic_id) and source = 'user' and verified = false);
create policy medicines_update on medicines for update to authenticated
  using (clinic_id is not null and is_prescriber(clinic_id) and source = 'user')
  with check (clinic_id is not null and is_prescriber(clinic_id) and source = 'user' and verified = false);
create policy medicines_delete on medicines for delete to authenticated
  using (clinic_id is not null and is_prescriber(clinic_id) and source = 'user');
-- The shared catalogue (clinic_id is null) is writable only by service_role / migrations.

create policy favorites_all on medicine_favorites for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------- appointments & follow-ups
create policy appointments_select on appointments for select to authenticated
  using (is_member(clinic_id));
create policy appointments_insert on appointments for insert to authenticated
  with check (can_write_clinical(clinic_id) and created_by = auth.uid());
create policy appointments_update on appointments for update to authenticated
  using (can_write_clinical(clinic_id)) with check (can_write_clinical(clinic_id));

create policy followups_select on followups for select to authenticated
  using (is_member(clinic_id));
create policy followups_insert on followups for insert to authenticated
  with check (can_write_clinical(clinic_id) and created_by = auth.uid());
create policy followups_update on followups for update to authenticated
  using (can_write_clinical(clinic_id)) with check (can_write_clinical(clinic_id));

-- ---------------------------------------------------------------- prescriptions
create policy prescriptions_select on prescriptions for select to authenticated
  using (is_member(clinic_id));
create policy prescriptions_insert on prescriptions for insert to authenticated
  with check (is_prescriber(clinic_id) and doctor_id = auth.uid()
              and status = 'draft' and amends_id is null);
create policy prescriptions_update on prescriptions for update to authenticated
  using (is_prescriber(clinic_id) and doctor_id = auth.uid() and status = 'draft')
  with check (is_prescriber(clinic_id) and doctor_id = auth.uid() and status in ('draft', 'finalized'));
create policy prescriptions_delete on prescriptions for delete to authenticated
  using (is_prescriber(clinic_id) and doctor_id = auth.uid() and status = 'draft');

create policy rx_meds_select on prescription_medications for select to authenticated
  using (is_member(clinic_id));
create policy rx_meds_write on prescription_medications for all to authenticated
  using (is_prescriber(clinic_id) and exists (
           select 1 from prescriptions p
           where p.id = prescription_id and p.doctor_id = auth.uid()))
  with check (is_prescriber(clinic_id) and exists (
           select 1 from prescriptions p
           where p.id = prescription_id and p.doctor_id = auth.uid()));

create policy rx_versions_select on prescription_versions for select to authenticated
  using (is_member(clinic_id));

-- ---------------------------------------------------------------- audit
create policy audit_select on audit_events for select to authenticated
  using (clinic_id is not null and current_role_in(clinic_id) = 'owner');
